
package transaction.doslb.tv.bell.ca.retrievelocalaccount;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the transaction.doslb.tv.bell.ca.retrievelocalaccount package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: transaction.doslb.tv.bell.ca.retrievelocalaccount
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse }
     * 
     */
    public RetrieveLocalAccountResponse createRetrieveLocalAccountResponse() {
        return new RetrieveLocalAccountResponse();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountRequest }
     * 
     */
    public RetrieveLocalAccountRequest createRetrieveLocalAccountRequest() {
        return new RetrieveLocalAccountRequest();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.ResponseInfo }
     * 
     */
    public RetrieveLocalAccountResponse.ResponseInfo createRetrieveLocalAccountResponseResponseInfo() {
        return new RetrieveLocalAccountResponse.ResponseInfo();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages }
     * 
     */
    public RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages createRetrieveLocalAccountResponseResponseInfoErrorMessages() {
        return new RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount createRetrieveLocalAccountResponseBillAccount() {
        return new RetrieveLocalAccountResponse.BillAccount();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 createRetrieveLocalAccountResponseBillAccountChargeInstalments2() {
        return new RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments createRetrieveLocalAccountResponseBillAccountChargeInstalments() {
        return new RetrieveLocalAccountResponse.BillAccount.ChargeInstalments();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Contract }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Contract createRetrieveLocalAccountResponseBillAccountContract() {
        return new RetrieveLocalAccountResponse.BillAccount.Contract();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Contract.Equipment }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Contract.Equipment createRetrieveLocalAccountResponseBillAccountContractEquipment() {
        return new RetrieveLocalAccountResponse.BillAccount.Contract.Equipment();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Contract.Account createRetrieveLocalAccountResponseBillAccountContractAccount() {
        return new RetrieveLocalAccountResponse.BillAccount.Contract.Account();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Promotions }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Promotions createRetrieveLocalAccountResponseBillAccountPromotions() {
        return new RetrieveLocalAccountResponse.BillAccount.Promotions();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountProduct createRetrieveLocalAccountResponseBillAccountAccountProduct() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountProduct();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader createRetrieveLocalAccountResponseBillAccountAccountProductProductHeader() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.BTVCustomer createRetrieveLocalAccountResponseBillAccountBTVCustomer() {
        return new RetrieveLocalAccountResponse.BillAccount.BTVCustomer();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountHeader createRetrieveLocalAccountResponseBillAccountAccountHeader() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountHeader();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes createRetrieveLocalAccountResponseBillAccountAccountHeaderExtendedAttributes() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities createRetrieveLocalAccountResponseBillAccountAccountHeaderExtendedAttributesIdentities() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountRequest.SectionsRequired }
     * 
     */
    public RetrieveLocalAccountRequest.SectionsRequired createRetrieveLocalAccountRequestSectionsRequired() {
        return new RetrieveLocalAccountRequest.SectionsRequired();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage }
     * 
     */
    public RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage createRetrieveLocalAccountResponseResponseInfoErrorMessagesErrorMessage() {
        return new RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountAddress }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountAddress createRetrieveLocalAccountResponseBillAccountAccountAddress() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountAddress();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Invoice }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Invoice createRetrieveLocalAccountResponseBillAccountInvoice() {
        return new RetrieveLocalAccountResponse.BillAccount.Invoice();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment createRetrieveLocalAccountResponseBillAccountChargeInstalments2ChargeInstalment() {
        return new RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment createRetrieveLocalAccountResponseBillAccountChargeInstalmentsChargeInstalment() {
        return new RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement createRetrieveLocalAccountResponseBillAccountContractEquipmentEquipmentAgreement() {
        return new RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement createRetrieveLocalAccountResponseBillAccountContractAccountAccountAgreement() {
        return new RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails createRetrieveLocalAccountResponseBillAccountPromotionsPromotionDetails() {
        return new RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode createRetrieveLocalAccountResponseBillAccountAccountProductProductHeaderProductCode() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification createRetrieveLocalAccountResponseBillAccountBTVCustomerCustomerIdentification() {
        return new RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos createRetrieveLocalAccountResponseBillAccountAccountHeaderExtendedAttributesControlInfos() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos();
    }

    /**
     * Create an instance of {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType }
     * 
     */
    public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType createRetrieveLocalAccountResponseBillAccountAccountHeaderExtendedAttributesIdentitiesCustomerType() {
        return new RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType();
    }

}
