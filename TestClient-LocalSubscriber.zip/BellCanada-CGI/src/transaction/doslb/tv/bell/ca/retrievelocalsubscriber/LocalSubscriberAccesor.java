package transaction.doslb.tv.bell.ca.retrievelocalsubscriber;

import java.io.*;
import com.terracotta.util.*;
import java.net.*;
import java.util.List;

import javax.xml.namespace.*;

import com.codahale.metrics.Histogram;

public class LocalSubscriberAccesor implements Runnable {

	private List<String> data;
	private int count = 0;
	private int index = 0;
	private RetrieveLocalSubscriberTransactionService service;
	private RetrieveLocalSubscriberTransaction port;
	private Histogram latency;
	boolean random = false;
	private RandomUtil rdmutil = new RandomUtil();
	
	public LocalSubscriberAccesor(String wsdlurl, List<String> data, int count,
			int index, Histogram latency, boolean random) throws Exception {
		this.data = data;
		this.count = count;
		this.index = index;
		this.latency = latency;
		this.random = random;
		URL wsdlURL = new URL(
				"file:wsdl/retrieveLocalSubscriberTransaction.wsdl");

		service = new RetrieveLocalSubscriberTransactionService(wsdlURL,
				RetrieveLocalSubscriberTransactionService.SERVICE);

		port = service
				.getPort(
						RetrieveLocalSubscriberTransactionService.RetrieveLocalSubscriberTransactionSoap11,
						RetrieveLocalSubscriberTransaction.class);

	}

	@Override
	public void run() {

		for (int i = 0; i < count; i++) {
			
			RetrieveLocalSubscriberRequest req = new RetrieveLocalSubscriberRequest();
			if (random){
				
			req.setCSGAccountNumber(data.get(rdmutil.generateRandom(data.size())));
			}else{
				req.setCSGAccountNumber(data.get(i + index));
			}
			req.setApplicationId("MB");
			RetrieveLocalSubscriberRequest.SectionsRequired sec = new RetrieveLocalSubscriberRequest.SectionsRequired();
			req.setSectionsRequired(sec);
			sec.getSection().add("SU");
			sec.getSection().add("SI");
			sec.getSection().add("EQ");
			sec.getSection().add("CO");
			sec.getSection().add("IN");
			sec.getSection().add("IN2");
			sec.getSection().add("AC");
			sec.getSection().add("XE");
			sec.getSection().add("BBM");

			ExecTime result = new ExecTime();
			result.startRecording();
			RetrieveLocalSubscriberResponse res = port
					.retrieveLocalSubscriber(req);
			result.stopRecording();
			latency.update(result.getTimeLapse());
			System.out.println("Server responded with: " + res);

		}
	}
}
