@javax.xml.bind.annotation.XmlSchema(namespace = "http://ca.bell.tv.doslb.transaction/RetrieveLocalAccount", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package transaction.doslb.tv.bell.ca.retrievelocalaccount;
