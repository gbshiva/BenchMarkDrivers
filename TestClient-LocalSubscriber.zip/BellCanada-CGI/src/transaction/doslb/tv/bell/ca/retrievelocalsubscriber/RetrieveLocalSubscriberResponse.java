
package transaction.doslb.tv.bell.ca.retrievelocalsubscriber;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Subscriber" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SubscriberHeader" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="SubscriberFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="SubscriberLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="SubscriberTelephoneNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="SubscriberStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="VacationTPSStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="TemporarySuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                             &lt;element name="TemporarySuspensionEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                             &lt;element name="NonPayStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="ExtendedAttributes" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Identities" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="CustomerType" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                                         &lt;sequence>
 *                                                           &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                                           &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                         &lt;/sequence>
 *                                                       &lt;/restriction>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element name="ControlInfos" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="ServiceLocation" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ServiceAddress">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Subscription" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="SubscriptionHeader">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ProgrammingPlatform" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Item" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="SubscriptionItem" maxOccurs="unbounded" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="SubscriptionServiceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="SubscriptionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="ServiceStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="DescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="DescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Equipment" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="SubscriptionEquipment" maxOccurs="unbounded" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="EquipmentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="ModelNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="IsWirelessModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="Ownership" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="EquipmentNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="DeviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="NumberOfTuners" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                                 &lt;element name="Outlet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="RMA" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="ExtendedAttributes" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                                         &lt;sequence>
 *                                                           &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *                                                           &lt;element name="AccessorySubType" minOccurs="0">
 *                                                             &lt;simpleType>
 *                                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                                 &lt;enumeration value="WRT"/>
 *                                                               &lt;/restriction>
 *                                                             &lt;/simpleType>
 *                                                           &lt;/element>
 *                                                         &lt;/sequence>
 *                                                       &lt;/restriction>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="AssignedResources" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="AssignedSatelites" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="NumberOfLNBOnDish" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Contract" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Account" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="AccountAgreement">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                                         &lt;sequence>
 *                                                           &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                           &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                           &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                           &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                           &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                           &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                         &lt;/sequence>
 *                                                       &lt;/restriction>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element name="Equipment" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                                         &lt;sequence>
 *                                                           &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                           &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                           &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                           &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                           &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                         &lt;/sequence>
 *                                                       &lt;/restriction>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="ChargeInstalments" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="ChargeInstalments2" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ResponseInfo">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SystemCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="SystemMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="TransactionId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="ErrorMessages" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ErrorMessage" maxOccurs="unbounded">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "subscriber",
    "responseInfo"
})
@XmlRootElement(name = "RetrieveLocalSubscriberResponse")
public class RetrieveLocalSubscriberResponse {

    @XmlElement(name = "Subscriber")
    protected RetrieveLocalSubscriberResponse.Subscriber subscriber;
    @XmlElement(name = "ResponseInfo", required = true)
    protected RetrieveLocalSubscriberResponse.ResponseInfo responseInfo;

    /**
     * Gets the value of the subscriber property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveLocalSubscriberResponse.Subscriber }
     *     
     */
    public RetrieveLocalSubscriberResponse.Subscriber getSubscriber() {
        return subscriber;
    }

    /**
     * Sets the value of the subscriber property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveLocalSubscriberResponse.Subscriber }
     *     
     */
    public void setSubscriber(RetrieveLocalSubscriberResponse.Subscriber value) {
        this.subscriber = value;
    }

    /**
     * Gets the value of the responseInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveLocalSubscriberResponse.ResponseInfo }
     *     
     */
    public RetrieveLocalSubscriberResponse.ResponseInfo getResponseInfo() {
        return responseInfo;
    }

    /**
     * Sets the value of the responseInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveLocalSubscriberResponse.ResponseInfo }
     *     
     */
    public void setResponseInfo(RetrieveLocalSubscriberResponse.ResponseInfo value) {
        this.responseInfo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SystemCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="SystemMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="TransactionId" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="ErrorMessages" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ErrorMessage" maxOccurs="unbounded">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "systemCode",
        "systemMessageType",
        "transactionId",
        "errorMessages"
    })
    public static class ResponseInfo {

        @XmlElement(name = "SystemCode")
        protected int systemCode;
        @XmlElement(name = "SystemMessageType", required = true)
        protected String systemMessageType;
        @XmlElement(name = "TransactionId")
        protected int transactionId;
        @XmlElement(name = "ErrorMessages")
        protected RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages errorMessages;

        /**
         * Gets the value of the systemCode property.
         * 
         */
        public int getSystemCode() {
            return systemCode;
        }

        /**
         * Sets the value of the systemCode property.
         * 
         */
        public void setSystemCode(int value) {
            this.systemCode = value;
        }

        /**
         * Gets the value of the systemMessageType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSystemMessageType() {
            return systemMessageType;
        }

        /**
         * Sets the value of the systemMessageType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSystemMessageType(String value) {
            this.systemMessageType = value;
        }

        /**
         * Gets the value of the transactionId property.
         * 
         */
        public int getTransactionId() {
            return transactionId;
        }

        /**
         * Sets the value of the transactionId property.
         * 
         */
        public void setTransactionId(int value) {
            this.transactionId = value;
        }

        /**
         * Gets the value of the errorMessages property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages }
         *     
         */
        public RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages getErrorMessages() {
            return errorMessages;
        }

        /**
         * Sets the value of the errorMessages property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages }
         *     
         */
        public void setErrorMessages(RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages value) {
            this.errorMessages = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ErrorMessage" maxOccurs="unbounded">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "errorMessage"
        })
        public static class ErrorMessages {

            @XmlElement(name = "ErrorMessage", required = true)
            protected List<RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage> errorMessage;

            /**
             * Gets the value of the errorMessage property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the errorMessage property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getErrorMessage().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage }
             * 
             * 
             */
            public List<RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage> getErrorMessage() {
                if (errorMessage == null) {
                    errorMessage = new ArrayList<RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage>();
                }
                return this.errorMessage;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "errorMessageCode",
                "errorMessageText",
                "errorMessageTextFr"
            })
            public static class ErrorMessage {

                @XmlElement(name = "ErrorMessageCode", required = true)
                protected String errorMessageCode;
                @XmlElement(name = "ErrorMessageText", required = true)
                protected String errorMessageText;
                @XmlElement(name = "ErrorMessageTextFr")
                protected String errorMessageTextFr;

                /**
                 * Gets the value of the errorMessageCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageCode() {
                    return errorMessageCode;
                }

                /**
                 * Sets the value of the errorMessageCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageCode(String value) {
                    this.errorMessageCode = value;
                }

                /**
                 * Gets the value of the errorMessageText property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageText() {
                    return errorMessageText;
                }

                /**
                 * Sets the value of the errorMessageText property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageText(String value) {
                    this.errorMessageText = value;
                }

                /**
                 * Gets the value of the errorMessageTextFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageTextFr() {
                    return errorMessageTextFr;
                }

                /**
                 * Sets the value of the errorMessageTextFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageTextFr(String value) {
                    this.errorMessageTextFr = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SubscriberHeader" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="SubscriberFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="SubscriberLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="SubscriberTelephoneNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="SubscriberStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="VacationTPSStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="TemporarySuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                   &lt;element name="TemporarySuspensionEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                   &lt;element name="NonPayStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="ExtendedAttributes" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Identities" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="CustomerType" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                               &lt;sequence>
     *                                                 &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                                                 &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                               &lt;/sequence>
     *                                             &lt;/restriction>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element name="ControlInfos" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="ServiceLocation" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ServiceAddress">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Subscription" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="SubscriptionHeader">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ProgrammingPlatform" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Item" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="SubscriptionItem" maxOccurs="unbounded" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="SubscriptionServiceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="SubscriptionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="ServiceStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="DescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="DescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Equipment" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="SubscriptionEquipment" maxOccurs="unbounded" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="EquipmentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="ModelNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="IsWirelessModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="Ownership" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="EquipmentNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="DeviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="NumberOfTuners" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                                       &lt;element name="Outlet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="RMA" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="ExtendedAttributes" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                               &lt;sequence>
     *                                                 &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
     *                                                 &lt;element name="AccessorySubType" minOccurs="0">
     *                                                   &lt;simpleType>
     *                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                                       &lt;enumeration value="WRT"/>
     *                                                     &lt;/restriction>
     *                                                   &lt;/simpleType>
     *                                                 &lt;/element>
     *                                               &lt;/sequence>
     *                                             &lt;/restriction>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="AssignedResources" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="AssignedSatelites" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="NumberOfLNBOnDish" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Contract" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Account" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="AccountAgreement">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                               &lt;sequence>
     *                                                 &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                                 &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                                 &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                                 &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                                 &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                                 &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                               &lt;/sequence>
     *                                             &lt;/restriction>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element name="Equipment" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                               &lt;sequence>
     *                                                 &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                                 &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                                 &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                                 &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                                 &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                               &lt;/sequence>
     *                                             &lt;/restriction>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="ChargeInstalments" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="ChargeInstalments2" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "subscriberHeader",
        "serviceLocation",
        "subscription",
        "chargeInstalments",
        "chargeInstalments2"
    })
    public static class Subscriber {

        @XmlElement(name = "SubscriberHeader")
        protected RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader subscriberHeader;
        @XmlElement(name = "ServiceLocation")
        protected RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation serviceLocation;
        @XmlElement(name = "Subscription")
        protected RetrieveLocalSubscriberResponse.Subscriber.Subscription subscription;
        @XmlElement(name = "ChargeInstalments")
        protected RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments chargeInstalments;
        @XmlElement(name = "ChargeInstalments2")
        protected RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 chargeInstalments2;

        /**
         * Gets the value of the subscriberHeader property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader }
         *     
         */
        public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader getSubscriberHeader() {
            return subscriberHeader;
        }

        /**
         * Sets the value of the subscriberHeader property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader }
         *     
         */
        public void setSubscriberHeader(RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader value) {
            this.subscriberHeader = value;
        }

        /**
         * Gets the value of the serviceLocation property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation }
         *     
         */
        public RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation getServiceLocation() {
            return serviceLocation;
        }

        /**
         * Sets the value of the serviceLocation property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation }
         *     
         */
        public void setServiceLocation(RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation value) {
            this.serviceLocation = value;
        }

        /**
         * Gets the value of the subscription property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription }
         *     
         */
        public RetrieveLocalSubscriberResponse.Subscriber.Subscription getSubscription() {
            return subscription;
        }

        /**
         * Sets the value of the subscription property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription }
         *     
         */
        public void setSubscription(RetrieveLocalSubscriberResponse.Subscriber.Subscription value) {
            this.subscription = value;
        }

        /**
         * Gets the value of the chargeInstalments property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments }
         *     
         */
        public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments getChargeInstalments() {
            return chargeInstalments;
        }

        /**
         * Sets the value of the chargeInstalments property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments }
         *     
         */
        public void setChargeInstalments(RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments value) {
            this.chargeInstalments = value;
        }

        /**
         * Gets the value of the chargeInstalments2 property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 }
         *     
         */
        public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 getChargeInstalments2() {
            return chargeInstalments2;
        }

        /**
         * Sets the value of the chargeInstalments2 property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 }
         *     
         */
        public void setChargeInstalments2(RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 value) {
            this.chargeInstalments2 = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargeInstalment"
        })
        public static class ChargeInstalments {

            @XmlElement(name = "ChargeInstalment")
            protected List<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment> chargeInstalment;

            /**
             * Gets the value of the chargeInstalment property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the chargeInstalment property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getChargeInstalment().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment }
             * 
             * 
             */
            public List<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment> getChargeInstalment() {
                if (chargeInstalment == null) {
                    chargeInstalment = new ArrayList<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment>();
                }
                return this.chargeInstalment;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "totalAmount",
                "monthlyCharge",
                "totalAmountCharged",
                "totalNumberOfCharges",
                "numberOfChargesSent",
                "numberOfChargesRemaining",
                "balance",
                "equipmentIdentifier",
                "instalmentStartDate",
                "instalmentEndDate"
            })
            public static class ChargeInstalment {

                @XmlElement(name = "TotalAmount")
                protected BigDecimal totalAmount;
                @XmlElement(name = "MonthlyCharge")
                protected BigDecimal monthlyCharge;
                @XmlElement(name = "TotalAmountCharged")
                protected BigDecimal totalAmountCharged;
                @XmlElement(name = "TotalNumberOfCharges")
                protected Integer totalNumberOfCharges;
                @XmlElement(name = "NumberOfChargesSent")
                protected Integer numberOfChargesSent;
                @XmlElement(name = "NumberOfChargesRemaining")
                protected Integer numberOfChargesRemaining;
                @XmlElement(name = "Balance")
                protected BigDecimal balance;
                @XmlElement(name = "EquipmentIdentifier")
                protected String equipmentIdentifier;
                @XmlElement(name = "InstalmentStartDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentStartDate;
                @XmlElement(name = "InstalmentEndDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentEndDate;

                /**
                 * Gets the value of the totalAmount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmount() {
                    return totalAmount;
                }

                /**
                 * Sets the value of the totalAmount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmount(BigDecimal value) {
                    this.totalAmount = value;
                }

                /**
                 * Gets the value of the monthlyCharge property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getMonthlyCharge() {
                    return monthlyCharge;
                }

                /**
                 * Sets the value of the monthlyCharge property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setMonthlyCharge(BigDecimal value) {
                    this.monthlyCharge = value;
                }

                /**
                 * Gets the value of the totalAmountCharged property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmountCharged() {
                    return totalAmountCharged;
                }

                /**
                 * Sets the value of the totalAmountCharged property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmountCharged(BigDecimal value) {
                    this.totalAmountCharged = value;
                }

                /**
                 * Gets the value of the totalNumberOfCharges property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getTotalNumberOfCharges() {
                    return totalNumberOfCharges;
                }

                /**
                 * Sets the value of the totalNumberOfCharges property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setTotalNumberOfCharges(Integer value) {
                    this.totalNumberOfCharges = value;
                }

                /**
                 * Gets the value of the numberOfChargesSent property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesSent() {
                    return numberOfChargesSent;
                }

                /**
                 * Sets the value of the numberOfChargesSent property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesSent(Integer value) {
                    this.numberOfChargesSent = value;
                }

                /**
                 * Gets the value of the numberOfChargesRemaining property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesRemaining() {
                    return numberOfChargesRemaining;
                }

                /**
                 * Sets the value of the numberOfChargesRemaining property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesRemaining(Integer value) {
                    this.numberOfChargesRemaining = value;
                }

                /**
                 * Gets the value of the balance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getBalance() {
                    return balance;
                }

                /**
                 * Sets the value of the balance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setBalance(BigDecimal value) {
                    this.balance = value;
                }

                /**
                 * Gets the value of the equipmentIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getEquipmentIdentifier() {
                    return equipmentIdentifier;
                }

                /**
                 * Sets the value of the equipmentIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setEquipmentIdentifier(String value) {
                    this.equipmentIdentifier = value;
                }

                /**
                 * Gets the value of the instalmentStartDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentStartDate() {
                    return instalmentStartDate;
                }

                /**
                 * Sets the value of the instalmentStartDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentStartDate(XMLGregorianCalendar value) {
                    this.instalmentStartDate = value;
                }

                /**
                 * Gets the value of the instalmentEndDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentEndDate() {
                    return instalmentEndDate;
                }

                /**
                 * Sets the value of the instalmentEndDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentEndDate(XMLGregorianCalendar value) {
                    this.instalmentEndDate = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargeInstalment"
        })
        public static class ChargeInstalments2 {

            @XmlElement(name = "ChargeInstalment")
            protected List<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment> chargeInstalment;

            /**
             * Gets the value of the chargeInstalment property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the chargeInstalment property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getChargeInstalment().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment }
             * 
             * 
             */
            public List<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment> getChargeInstalment() {
                if (chargeInstalment == null) {
                    chargeInstalment = new ArrayList<RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment>();
                }
                return this.chargeInstalment;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "totalAmount",
                "monthlyCharge",
                "totalAmountCharged",
                "totalNumberOfCharges",
                "numberOfChargesSent",
                "numberOfChargesRemaining",
                "balance",
                "equipmentIdentifier",
                "instalmentStartDate",
                "instalmentEndDate",
                "instalmentDescriptionEn",
                "instalmentDescriptionFr"
            })
            public static class ChargeInstalment {

                @XmlElement(name = "TotalAmount")
                protected BigDecimal totalAmount;
                @XmlElement(name = "MonthlyCharge")
                protected BigDecimal monthlyCharge;
                @XmlElement(name = "TotalAmountCharged")
                protected BigDecimal totalAmountCharged;
                @XmlElement(name = "TotalNumberOfCharges")
                protected Integer totalNumberOfCharges;
                @XmlElement(name = "NumberOfChargesSent")
                protected Integer numberOfChargesSent;
                @XmlElement(name = "NumberOfChargesRemaining")
                protected Integer numberOfChargesRemaining;
                @XmlElement(name = "Balance")
                protected BigDecimal balance;
                @XmlElement(name = "EquipmentIdentifier")
                protected String equipmentIdentifier;
                @XmlElement(name = "InstalmentStartDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentStartDate;
                @XmlElement(name = "InstalmentEndDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentEndDate;
                @XmlElement(name = "InstalmentDescriptionEn")
                protected String instalmentDescriptionEn;
                @XmlElement(name = "InstalmentDescriptionFr")
                protected String instalmentDescriptionFr;

                /**
                 * Gets the value of the totalAmount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmount() {
                    return totalAmount;
                }

                /**
                 * Sets the value of the totalAmount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmount(BigDecimal value) {
                    this.totalAmount = value;
                }

                /**
                 * Gets the value of the monthlyCharge property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getMonthlyCharge() {
                    return monthlyCharge;
                }

                /**
                 * Sets the value of the monthlyCharge property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setMonthlyCharge(BigDecimal value) {
                    this.monthlyCharge = value;
                }

                /**
                 * Gets the value of the totalAmountCharged property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmountCharged() {
                    return totalAmountCharged;
                }

                /**
                 * Sets the value of the totalAmountCharged property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmountCharged(BigDecimal value) {
                    this.totalAmountCharged = value;
                }

                /**
                 * Gets the value of the totalNumberOfCharges property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getTotalNumberOfCharges() {
                    return totalNumberOfCharges;
                }

                /**
                 * Sets the value of the totalNumberOfCharges property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setTotalNumberOfCharges(Integer value) {
                    this.totalNumberOfCharges = value;
                }

                /**
                 * Gets the value of the numberOfChargesSent property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesSent() {
                    return numberOfChargesSent;
                }

                /**
                 * Sets the value of the numberOfChargesSent property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesSent(Integer value) {
                    this.numberOfChargesSent = value;
                }

                /**
                 * Gets the value of the numberOfChargesRemaining property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesRemaining() {
                    return numberOfChargesRemaining;
                }

                /**
                 * Sets the value of the numberOfChargesRemaining property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesRemaining(Integer value) {
                    this.numberOfChargesRemaining = value;
                }

                /**
                 * Gets the value of the balance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getBalance() {
                    return balance;
                }

                /**
                 * Sets the value of the balance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setBalance(BigDecimal value) {
                    this.balance = value;
                }

                /**
                 * Gets the value of the equipmentIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getEquipmentIdentifier() {
                    return equipmentIdentifier;
                }

                /**
                 * Sets the value of the equipmentIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setEquipmentIdentifier(String value) {
                    this.equipmentIdentifier = value;
                }

                /**
                 * Gets the value of the instalmentStartDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentStartDate() {
                    return instalmentStartDate;
                }

                /**
                 * Sets the value of the instalmentStartDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentStartDate(XMLGregorianCalendar value) {
                    this.instalmentStartDate = value;
                }

                /**
                 * Gets the value of the instalmentEndDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentEndDate() {
                    return instalmentEndDate;
                }

                /**
                 * Sets the value of the instalmentEndDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentEndDate(XMLGregorianCalendar value) {
                    this.instalmentEndDate = value;
                }

                /**
                 * Gets the value of the instalmentDescriptionEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getInstalmentDescriptionEn() {
                    return instalmentDescriptionEn;
                }

                /**
                 * Sets the value of the instalmentDescriptionEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setInstalmentDescriptionEn(String value) {
                    this.instalmentDescriptionEn = value;
                }

                /**
                 * Gets the value of the instalmentDescriptionFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getInstalmentDescriptionFr() {
                    return instalmentDescriptionFr;
                }

                /**
                 * Sets the value of the instalmentDescriptionFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setInstalmentDescriptionFr(String value) {
                    this.instalmentDescriptionFr = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ServiceAddress">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "serviceAddress"
        })
        public static class ServiceLocation {

            @XmlElement(name = "ServiceAddress", required = true)
            protected RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress serviceAddress;

            /**
             * Gets the value of the serviceAddress property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress getServiceAddress() {
                return serviceAddress;
            }

            /**
             * Sets the value of the serviceAddress property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress }
             *     
             */
            public void setServiceAddress(RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress value) {
                this.serviceAddress = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "address1",
                "address2",
                "city",
                "postalCode",
                "provinceCode",
                "countryCode"
            })
            public static class ServiceAddress {

                @XmlElement(name = "Address1", required = true)
                protected String address1;
                @XmlElement(name = "Address2")
                protected String address2;
                @XmlElement(name = "City", required = true)
                protected String city;
                @XmlElement(name = "PostalCode", required = true)
                protected String postalCode;
                @XmlElement(name = "ProvinceCode", required = true)
                protected String provinceCode;
                @XmlElement(name = "CountryCode", required = true)
                protected String countryCode;

                /**
                 * Gets the value of the address1 property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAddress1() {
                    return address1;
                }

                /**
                 * Sets the value of the address1 property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAddress1(String value) {
                    this.address1 = value;
                }

                /**
                 * Gets the value of the address2 property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAddress2() {
                    return address2;
                }

                /**
                 * Sets the value of the address2 property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAddress2(String value) {
                    this.address2 = value;
                }

                /**
                 * Gets the value of the city property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCity() {
                    return city;
                }

                /**
                 * Sets the value of the city property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCity(String value) {
                    this.city = value;
                }

                /**
                 * Gets the value of the postalCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPostalCode() {
                    return postalCode;
                }

                /**
                 * Sets the value of the postalCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPostalCode(String value) {
                    this.postalCode = value;
                }

                /**
                 * Gets the value of the provinceCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getProvinceCode() {
                    return provinceCode;
                }

                /**
                 * Sets the value of the provinceCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setProvinceCode(String value) {
                    this.provinceCode = value;
                }

                /**
                 * Gets the value of the countryCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCountryCode() {
                    return countryCode;
                }

                /**
                 * Sets the value of the countryCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCountryCode(String value) {
                    this.countryCode = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="SubscriberFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="SubscriberLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="SubscriberTelephoneNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="SubscriberStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="VacationTPSStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="TemporarySuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *         &lt;element name="TemporarySuspensionEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *         &lt;element name="NonPayStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="ExtendedAttributes" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Identities" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="CustomerType" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                                     &lt;sequence>
         *                                       &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                                       &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                     &lt;/sequence>
         *                                   &lt;/restriction>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element name="ControlInfos" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "csgAccountNumber",
            "subscriberFirstName",
            "subscriberLastName",
            "subscriberTelephoneNumber",
            "subscriberStatus",
            "vacationTPSStatus",
            "temporarySuspensionStartDate",
            "temporarySuspensionEndDate",
            "nonPayStatus",
            "extendedAttributes"
        })
        public static class SubscriberHeader {

            @XmlElement(name = "CSGAccountNumber", required = true)
            protected String csgAccountNumber;
            @XmlElement(name = "SubscriberFirstName")
            protected String subscriberFirstName;
            @XmlElement(name = "SubscriberLastName")
            protected String subscriberLastName;
            @XmlElement(name = "SubscriberTelephoneNumber", required = true)
            protected String subscriberTelephoneNumber;
            @XmlElement(name = "SubscriberStatus", required = true)
            protected String subscriberStatus;
            @XmlElement(name = "VacationTPSStatus", required = true)
            protected String vacationTPSStatus;
            @XmlElement(name = "TemporarySuspensionStartDate")
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar temporarySuspensionStartDate;
            @XmlElement(name = "TemporarySuspensionEndDate")
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar temporarySuspensionEndDate;
            @XmlElement(name = "NonPayStatus", required = true)
            protected String nonPayStatus;
            @XmlElement(name = "ExtendedAttributes")
            protected RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes extendedAttributes;

            /**
             * Gets the value of the csgAccountNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCSGAccountNumber() {
                return csgAccountNumber;
            }

            /**
             * Sets the value of the csgAccountNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCSGAccountNumber(String value) {
                this.csgAccountNumber = value;
            }

            /**
             * Gets the value of the subscriberFirstName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSubscriberFirstName() {
                return subscriberFirstName;
            }

            /**
             * Sets the value of the subscriberFirstName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSubscriberFirstName(String value) {
                this.subscriberFirstName = value;
            }

            /**
             * Gets the value of the subscriberLastName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSubscriberLastName() {
                return subscriberLastName;
            }

            /**
             * Sets the value of the subscriberLastName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSubscriberLastName(String value) {
                this.subscriberLastName = value;
            }

            /**
             * Gets the value of the subscriberTelephoneNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSubscriberTelephoneNumber() {
                return subscriberTelephoneNumber;
            }

            /**
             * Sets the value of the subscriberTelephoneNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSubscriberTelephoneNumber(String value) {
                this.subscriberTelephoneNumber = value;
            }

            /**
             * Gets the value of the subscriberStatus property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSubscriberStatus() {
                return subscriberStatus;
            }

            /**
             * Sets the value of the subscriberStatus property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSubscriberStatus(String value) {
                this.subscriberStatus = value;
            }

            /**
             * Gets the value of the vacationTPSStatus property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVacationTPSStatus() {
                return vacationTPSStatus;
            }

            /**
             * Sets the value of the vacationTPSStatus property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVacationTPSStatus(String value) {
                this.vacationTPSStatus = value;
            }

            /**
             * Gets the value of the temporarySuspensionStartDate property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getTemporarySuspensionStartDate() {
                return temporarySuspensionStartDate;
            }

            /**
             * Sets the value of the temporarySuspensionStartDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setTemporarySuspensionStartDate(XMLGregorianCalendar value) {
                this.temporarySuspensionStartDate = value;
            }

            /**
             * Gets the value of the temporarySuspensionEndDate property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getTemporarySuspensionEndDate() {
                return temporarySuspensionEndDate;
            }

            /**
             * Sets the value of the temporarySuspensionEndDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setTemporarySuspensionEndDate(XMLGregorianCalendar value) {
                this.temporarySuspensionEndDate = value;
            }

            /**
             * Gets the value of the nonPayStatus property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getNonPayStatus() {
                return nonPayStatus;
            }

            /**
             * Sets the value of the nonPayStatus property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setNonPayStatus(String value) {
                this.nonPayStatus = value;
            }

            /**
             * Gets the value of the extendedAttributes property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes getExtendedAttributes() {
                return extendedAttributes;
            }

            /**
             * Sets the value of the extendedAttributes property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes }
             *     
             */
            public void setExtendedAttributes(RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes value) {
                this.extendedAttributes = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Identities" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="CustomerType" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                           &lt;sequence>
             *                             &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *                             &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                           &lt;/sequence>
             *                         &lt;/restriction>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element name="ControlInfos" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "identities",
                "controlInfos"
            })
            public static class ExtendedAttributes {

                @XmlElement(name = "Identities")
                protected RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities identities;
                @XmlElement(name = "ControlInfos")
                protected RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos controlInfos;

                /**
                 * Gets the value of the identities property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities }
                 *     
                 */
                public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities getIdentities() {
                    return identities;
                }

                /**
                 * Sets the value of the identities property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities }
                 *     
                 */
                public void setIdentities(RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities value) {
                    this.identities = value;
                }

                /**
                 * Gets the value of the controlInfos property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos }
                 *     
                 */
                public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos getControlInfos() {
                    return controlInfos;
                }

                /**
                 * Sets the value of the controlInfos property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos }
                 *     
                 */
                public void setControlInfos(RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos value) {
                    this.controlInfos = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "seatingCapacity"
                })
                public static class ControlInfos {

                    @XmlElement(name = "SeatingCapacity")
                    protected Integer seatingCapacity;

                    /**
                     * Gets the value of the seatingCapacity property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link Integer }
                     *     
                     */
                    public Integer getSeatingCapacity() {
                        return seatingCapacity;
                    }

                    /**
                     * Sets the value of the seatingCapacity property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link Integer }
                     *     
                     */
                    public void setSeatingCapacity(Integer value) {
                        this.seatingCapacity = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="CustomerType" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *                 &lt;sequence>
                 *                   &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                 *                   &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                 &lt;/sequence>
                 *               &lt;/restriction>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "b1",
                    "nm1BAN",
                    "customerType"
                })
                public static class Identities {

                    @XmlElement(name = "B1")
                    protected String b1;
                    @XmlElement(name = "NM1BAN")
                    protected String nm1BAN;
                    @XmlElement(name = "CustomerType")
                    protected RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType customerType;

                    /**
                     * Gets the value of the b1 property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getB1() {
                        return b1;
                    }

                    /**
                     * Sets the value of the b1 property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setB1(String value) {
                        this.b1 = value;
                    }

                    /**
                     * Gets the value of the nm1BAN property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getNM1BAN() {
                        return nm1BAN;
                    }

                    /**
                     * Sets the value of the nm1BAN property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setNM1BAN(String value) {
                        this.nm1BAN = value;
                    }

                    /**
                     * Gets the value of the customerType property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType }
                     *     
                     */
                    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType getCustomerType() {
                        return customerType;
                    }

                    /**
                     * Sets the value of the customerType property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType }
                     *     
                     */
                    public void setCustomerType(RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType value) {
                        this.customerType = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                     *       &lt;sequence>
                     *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                     *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *       &lt;/sequence>
                     *     &lt;/restriction>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "id",
                        "description"
                    })
                    public static class CustomerType {

                        @XmlElement(name = "ID")
                        protected Integer id;
                        @XmlElement(name = "Description")
                        protected String description;

                        /**
                         * Gets the value of the id property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link Integer }
                         *     
                         */
                        public Integer getID() {
                            return id;
                        }

                        /**
                         * Sets the value of the id property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link Integer }
                         *     
                         */
                        public void setID(Integer value) {
                            this.id = value;
                        }

                        /**
                         * Gets the value of the description property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDescription() {
                            return description;
                        }

                        /**
                         * Sets the value of the description property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDescription(String value) {
                            this.description = value;
                        }

                    }

                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="SubscriptionHeader">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ProgrammingPlatform" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Item" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="SubscriptionItem" maxOccurs="unbounded" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="SubscriptionServiceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="SubscriptionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="ServiceStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="DescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="DescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Equipment" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="SubscriptionEquipment" maxOccurs="unbounded" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="EquipmentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="ModelNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="IsWirelessModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="Ownership" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="EquipmentNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="DeviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="NumberOfTuners" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                             &lt;element name="Outlet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="RMA" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="ExtendedAttributes" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                                     &lt;sequence>
         *                                       &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
         *                                       &lt;element name="AccessorySubType" minOccurs="0">
         *                                         &lt;simpleType>
         *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                             &lt;enumeration value="WRT"/>
         *                                           &lt;/restriction>
         *                                         &lt;/simpleType>
         *                                       &lt;/element>
         *                                     &lt;/sequence>
         *                                   &lt;/restriction>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="AssignedResources" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="AssignedSatelites" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="NumberOfLNBOnDish" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Contract" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Account" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="AccountAgreement">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                                     &lt;sequence>
         *                                       &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                       &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                       &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                                       &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                                       &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                                       &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                     &lt;/sequence>
         *                                   &lt;/restriction>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element name="Equipment" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                                     &lt;sequence>
         *                                       &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                       &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                       &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                                       &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                                       &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                     &lt;/sequence>
         *                                   &lt;/restriction>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "subscriptionHeader",
            "item",
            "equipment",
            "assignedResources",
            "contract"
        })
        public static class Subscription {

            @XmlElement(name = "SubscriptionHeader", required = true)
            protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader subscriptionHeader;
            @XmlElement(name = "Item")
            protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item item;
            @XmlElement(name = "Equipment")
            protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment equipment;
            @XmlElement(name = "AssignedResources")
            protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources assignedResources;
            @XmlElement(name = "Contract")
            protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract contract;

            /**
             * Gets the value of the subscriptionHeader property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader getSubscriptionHeader() {
                return subscriptionHeader;
            }

            /**
             * Sets the value of the subscriptionHeader property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader }
             *     
             */
            public void setSubscriptionHeader(RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader value) {
                this.subscriptionHeader = value;
            }

            /**
             * Gets the value of the item property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item getItem() {
                return item;
            }

            /**
             * Sets the value of the item property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item }
             *     
             */
            public void setItem(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item value) {
                this.item = value;
            }

            /**
             * Gets the value of the equipment property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment getEquipment() {
                return equipment;
            }

            /**
             * Sets the value of the equipment property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment }
             *     
             */
            public void setEquipment(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment value) {
                this.equipment = value;
            }

            /**
             * Gets the value of the assignedResources property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources getAssignedResources() {
                return assignedResources;
            }

            /**
             * Sets the value of the assignedResources property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources }
             *     
             */
            public void setAssignedResources(RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources value) {
                this.assignedResources = value;
            }

            /**
             * Gets the value of the contract property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract }
             *     
             */
            public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract getContract() {
                return contract;
            }

            /**
             * Sets the value of the contract property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract }
             *     
             */
            public void setContract(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract value) {
                this.contract = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="AssignedSatelites" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="NumberOfLNBOnDish" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "assignedSatelites",
                "numberOfLNBOnDish"
            })
            public static class AssignedResources {

                @XmlElement(name = "AssignedSatelites")
                protected String assignedSatelites;
                @XmlElement(name = "NumberOfLNBOnDish")
                protected Integer numberOfLNBOnDish;

                /**
                 * Gets the value of the assignedSatelites property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAssignedSatelites() {
                    return assignedSatelites;
                }

                /**
                 * Sets the value of the assignedSatelites property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAssignedSatelites(String value) {
                    this.assignedSatelites = value;
                }

                /**
                 * Gets the value of the numberOfLNBOnDish property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfLNBOnDish() {
                    return numberOfLNBOnDish;
                }

                /**
                 * Sets the value of the numberOfLNBOnDish property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfLNBOnDish(Integer value) {
                    this.numberOfLNBOnDish = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Account" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="AccountAgreement">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                           &lt;sequence>
             *                             &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                             &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                             &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                             &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                             &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                             &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                           &lt;/sequence>
             *                         &lt;/restriction>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element name="Equipment" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                           &lt;sequence>
             *                             &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                             &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                             &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                             &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                             &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                           &lt;/sequence>
             *                         &lt;/restriction>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "account",
                "equipment"
            })
            public static class Contract {

                @XmlElement(name = "Account")
                protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account account;
                @XmlElement(name = "Equipment")
                protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment equipment;

                /**
                 * Gets the value of the account property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account }
                 *     
                 */
                public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account getAccount() {
                    return account;
                }

                /**
                 * Sets the value of the account property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account }
                 *     
                 */
                public void setAccount(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account value) {
                    this.account = value;
                }

                /**
                 * Gets the value of the equipment property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment }
                 *     
                 */
                public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment getEquipment() {
                    return equipment;
                }

                /**
                 * Sets the value of the equipment property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment }
                 *     
                 */
                public void setEquipment(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment value) {
                    this.equipment = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="AccountAgreement">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *                 &lt;sequence>
                 *                   &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                   &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                   &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *                   &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *                   &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *                   &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                 &lt;/sequence>
                 *               &lt;/restriction>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "accountAgreement"
                })
                public static class Account {

                    @XmlElement(name = "AccountAgreement", required = true)
                    protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement accountAgreement;

                    /**
                     * Gets the value of the accountAgreement property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement }
                     *     
                     */
                    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement getAccountAgreement() {
                        return accountAgreement;
                    }

                    /**
                     * Sets the value of the accountAgreement property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement }
                     *     
                     */
                    public void setAccountAgreement(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement value) {
                        this.accountAgreement = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                     *       &lt;sequence>
                     *         &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *         &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *         &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                     *         &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                     *         &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                     *         &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *       &lt;/sequence>
                     *     &lt;/restriction>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "termCode",
                        "termMonth",
                        "agreementActivationDate",
                        "agreementSuspensionStartDate",
                        "agreementExpiryDate",
                        "freeUpgradesRemaining"
                    })
                    public static class AccountAgreement {

                        @XmlElement(name = "TermCode")
                        protected String termCode;
                        @XmlElement(name = "TermMonth")
                        protected String termMonth;
                        @XmlElement(name = "AgreementActivationDate")
                        @XmlSchemaType(name = "date")
                        protected XMLGregorianCalendar agreementActivationDate;
                        @XmlElement(name = "AgreementSuspensionStartDate")
                        @XmlSchemaType(name = "date")
                        protected XMLGregorianCalendar agreementSuspensionStartDate;
                        @XmlElement(name = "AgreementExpiryDate")
                        @XmlSchemaType(name = "date")
                        protected XMLGregorianCalendar agreementExpiryDate;
                        @XmlElement(name = "FreeUpgradesRemaining")
                        protected String freeUpgradesRemaining;

                        /**
                         * Gets the value of the termCode property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getTermCode() {
                            return termCode;
                        }

                        /**
                         * Sets the value of the termCode property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setTermCode(String value) {
                            this.termCode = value;
                        }

                        /**
                         * Gets the value of the termMonth property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getTermMonth() {
                            return termMonth;
                        }

                        /**
                         * Sets the value of the termMonth property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setTermMonth(String value) {
                            this.termMonth = value;
                        }

                        /**
                         * Gets the value of the agreementActivationDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getAgreementActivationDate() {
                            return agreementActivationDate;
                        }

                        /**
                         * Sets the value of the agreementActivationDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setAgreementActivationDate(XMLGregorianCalendar value) {
                            this.agreementActivationDate = value;
                        }

                        /**
                         * Gets the value of the agreementSuspensionStartDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getAgreementSuspensionStartDate() {
                            return agreementSuspensionStartDate;
                        }

                        /**
                         * Sets the value of the agreementSuspensionStartDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setAgreementSuspensionStartDate(XMLGregorianCalendar value) {
                            this.agreementSuspensionStartDate = value;
                        }

                        /**
                         * Gets the value of the agreementExpiryDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getAgreementExpiryDate() {
                            return agreementExpiryDate;
                        }

                        /**
                         * Sets the value of the agreementExpiryDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setAgreementExpiryDate(XMLGregorianCalendar value) {
                            this.agreementExpiryDate = value;
                        }

                        /**
                         * Gets the value of the freeUpgradesRemaining property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getFreeUpgradesRemaining() {
                            return freeUpgradesRemaining;
                        }

                        /**
                         * Sets the value of the freeUpgradesRemaining property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setFreeUpgradesRemaining(String value) {
                            this.freeUpgradesRemaining = value;
                        }

                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *                 &lt;sequence>
                 *                   &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                   &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                   &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *                   &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *                   &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                 &lt;/sequence>
                 *               &lt;/restriction>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "equipmentAgreement"
                })
                public static class Equipment {

                    @XmlElement(name = "EquipmentAgreement")
                    protected List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement> equipmentAgreement;

                    /**
                     * Gets the value of the equipmentAgreement property.
                     * 
                     * <p>
                     * This accessor method returns a reference to the live list,
                     * not a snapshot. Therefore any modification you make to the
                     * returned list will be present inside the JAXB object.
                     * This is why there is not a <CODE>set</CODE> method for the equipmentAgreement property.
                     * 
                     * <p>
                     * For example, to add a new item, do as follows:
                     * <pre>
                     *    getEquipmentAgreement().add(newItem);
                     * </pre>
                     * 
                     * 
                     * <p>
                     * Objects of the following type(s) are allowed in the list
                     * {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement }
                     * 
                     * 
                     */
                    public List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement> getEquipmentAgreement() {
                        if (equipmentAgreement == null) {
                            equipmentAgreement = new ArrayList<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement>();
                        }
                        return this.equipmentAgreement;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                     *       &lt;sequence>
                     *         &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *         &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *         &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                     *         &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                     *         &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *       &lt;/sequence>
                     *     &lt;/restriction>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "termCode",
                        "termMonth",
                        "agreementActivationDate",
                        "agreementDisconnectDate",
                        "hardwareIdenitifer"
                    })
                    public static class EquipmentAgreement {

                        @XmlElement(name = "TermCode")
                        protected String termCode;
                        @XmlElement(name = "TermMonth")
                        protected String termMonth;
                        @XmlElement(name = "AgreementActivationDate")
                        @XmlSchemaType(name = "date")
                        protected XMLGregorianCalendar agreementActivationDate;
                        @XmlElement(name = "AgreementDisconnectDate")
                        @XmlSchemaType(name = "date")
                        protected XMLGregorianCalendar agreementDisconnectDate;
                        @XmlElement(name = "HardwareIdenitifer")
                        protected String hardwareIdenitifer;

                        /**
                         * Gets the value of the termCode property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getTermCode() {
                            return termCode;
                        }

                        /**
                         * Sets the value of the termCode property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setTermCode(String value) {
                            this.termCode = value;
                        }

                        /**
                         * Gets the value of the termMonth property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getTermMonth() {
                            return termMonth;
                        }

                        /**
                         * Sets the value of the termMonth property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setTermMonth(String value) {
                            this.termMonth = value;
                        }

                        /**
                         * Gets the value of the agreementActivationDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getAgreementActivationDate() {
                            return agreementActivationDate;
                        }

                        /**
                         * Sets the value of the agreementActivationDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setAgreementActivationDate(XMLGregorianCalendar value) {
                            this.agreementActivationDate = value;
                        }

                        /**
                         * Gets the value of the agreementDisconnectDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getAgreementDisconnectDate() {
                            return agreementDisconnectDate;
                        }

                        /**
                         * Sets the value of the agreementDisconnectDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setAgreementDisconnectDate(XMLGregorianCalendar value) {
                            this.agreementDisconnectDate = value;
                        }

                        /**
                         * Gets the value of the hardwareIdenitifer property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getHardwareIdenitifer() {
                            return hardwareIdenitifer;
                        }

                        /**
                         * Sets the value of the hardwareIdenitifer property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setHardwareIdenitifer(String value) {
                            this.hardwareIdenitifer = value;
                        }

                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="SubscriptionEquipment" maxOccurs="unbounded" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="EquipmentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="ModelNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="IsWirelessModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="Ownership" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="EquipmentNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="DeviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="NumberOfTuners" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *                   &lt;element name="Outlet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="RMA" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="ExtendedAttributes" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                           &lt;sequence>
             *                             &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
             *                             &lt;element name="AccessorySubType" minOccurs="0">
             *                               &lt;simpleType>
             *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                                   &lt;enumeration value="WRT"/>
             *                                 &lt;/restriction>
             *                               &lt;/simpleType>
             *                             &lt;/element>
             *                           &lt;/sequence>
             *                         &lt;/restriction>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "subscriptionEquipment"
            })
            public static class Equipment {

                @XmlElement(name = "SubscriptionEquipment")
                protected List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment> subscriptionEquipment;

                /**
                 * Gets the value of the subscriptionEquipment property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the subscriptionEquipment property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getSubscriptionEquipment().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment }
                 * 
                 * 
                 */
                public List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment> getSubscriptionEquipment() {
                    if (subscriptionEquipment == null) {
                        subscriptionEquipment = new ArrayList<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment>();
                    }
                    return this.subscriptionEquipment;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="EquipmentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="ModelNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="IsWirelessModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="Ownership" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="EquipmentNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="DeviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="NumberOfTuners" type="{http://www.w3.org/2001/XMLSchema}int"/>
                 *         &lt;element name="Outlet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="RMA" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="Condition" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="ExtendedAttributes" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *                 &lt;sequence>
                 *                   &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
                 *                   &lt;element name="AccessorySubType" minOccurs="0">
                 *                     &lt;simpleType>
                 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *                         &lt;enumeration value="WRT"/>
                 *                       &lt;/restriction>
                 *                     &lt;/simpleType>
                 *                   &lt;/element>
                 *                 &lt;/sequence>
                 *               &lt;/restriction>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "equipmentType",
                    "modelNumber",
                    "isWirelessModel",
                    "ownership",
                    "equipmentNumber",
                    "deviceId",
                    "numberOfTuners",
                    "outlet",
                    "rma",
                    "condition",
                    "status",
                    "extendedAttributes"
                })
                public static class SubscriptionEquipment {

                    @XmlElement(name = "EquipmentType", required = true)
                    protected String equipmentType;
                    @XmlElement(name = "ModelNumber", required = true)
                    protected String modelNumber;
                    @XmlElement(name = "IsWirelessModel")
                    protected String isWirelessModel;
                    @XmlElement(name = "Ownership", required = true)
                    protected String ownership;
                    @XmlElement(name = "EquipmentNumber", required = true)
                    protected String equipmentNumber;
                    @XmlElement(name = "DeviceId")
                    protected String deviceId;
                    @XmlElement(name = "NumberOfTuners")
                    protected int numberOfTuners;
                    @XmlElement(name = "Outlet")
                    protected String outlet;
                    @XmlElement(name = "RMA", required = true)
                    protected String rma;
                    @XmlElement(name = "Condition", required = true)
                    protected String condition;
                    @XmlElement(name = "Status", required = true)
                    protected String status;
                    @XmlElement(name = "ExtendedAttributes")
                    protected RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes extendedAttributes;

                    /**
                     * Gets the value of the equipmentType property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getEquipmentType() {
                        return equipmentType;
                    }

                    /**
                     * Sets the value of the equipmentType property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setEquipmentType(String value) {
                        this.equipmentType = value;
                    }

                    /**
                     * Gets the value of the modelNumber property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getModelNumber() {
                        return modelNumber;
                    }

                    /**
                     * Sets the value of the modelNumber property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setModelNumber(String value) {
                        this.modelNumber = value;
                    }

                    /**
                     * Gets the value of the isWirelessModel property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIsWirelessModel() {
                        return isWirelessModel;
                    }

                    /**
                     * Sets the value of the isWirelessModel property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIsWirelessModel(String value) {
                        this.isWirelessModel = value;
                    }

                    /**
                     * Gets the value of the ownership property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getOwnership() {
                        return ownership;
                    }

                    /**
                     * Sets the value of the ownership property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setOwnership(String value) {
                        this.ownership = value;
                    }

                    /**
                     * Gets the value of the equipmentNumber property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getEquipmentNumber() {
                        return equipmentNumber;
                    }

                    /**
                     * Sets the value of the equipmentNumber property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setEquipmentNumber(String value) {
                        this.equipmentNumber = value;
                    }

                    /**
                     * Gets the value of the deviceId property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDeviceId() {
                        return deviceId;
                    }

                    /**
                     * Sets the value of the deviceId property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDeviceId(String value) {
                        this.deviceId = value;
                    }

                    /**
                     * Gets the value of the numberOfTuners property.
                     * 
                     */
                    public int getNumberOfTuners() {
                        return numberOfTuners;
                    }

                    /**
                     * Sets the value of the numberOfTuners property.
                     * 
                     */
                    public void setNumberOfTuners(int value) {
                        this.numberOfTuners = value;
                    }

                    /**
                     * Gets the value of the outlet property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getOutlet() {
                        return outlet;
                    }

                    /**
                     * Sets the value of the outlet property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setOutlet(String value) {
                        this.outlet = value;
                    }

                    /**
                     * Gets the value of the rma property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getRMA() {
                        return rma;
                    }

                    /**
                     * Sets the value of the rma property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setRMA(String value) {
                        this.rma = value;
                    }

                    /**
                     * Gets the value of the condition property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCondition() {
                        return condition;
                    }

                    /**
                     * Sets the value of the condition property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCondition(String value) {
                        this.condition = value;
                    }

                    /**
                     * Gets the value of the status property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getStatus() {
                        return status;
                    }

                    /**
                     * Sets the value of the status property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setStatus(String value) {
                        this.status = value;
                    }

                    /**
                     * Gets the value of the extendedAttributes property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes }
                     *     
                     */
                    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes getExtendedAttributes() {
                        return extendedAttributes;
                    }

                    /**
                     * Sets the value of the extendedAttributes property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes }
                     *     
                     */
                    public void setExtendedAttributes(RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes value) {
                        this.extendedAttributes = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                     *       &lt;sequence>
                     *         &lt;element name="LastActivationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
                     *         &lt;element name="AccessorySubType" minOccurs="0">
                     *           &lt;simpleType>
                     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                     *               &lt;enumeration value="WRT"/>
                     *             &lt;/restriction>
                     *           &lt;/simpleType>
                     *         &lt;/element>
                     *       &lt;/sequence>
                     *     &lt;/restriction>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "lastActivationDate",
                        "accessorySubType"
                    })
                    public static class ExtendedAttributes {

                        @XmlElement(name = "LastActivationDate")
                        @XmlSchemaType(name = "dateTime")
                        protected XMLGregorianCalendar lastActivationDate;
                        @XmlElement(name = "AccessorySubType")
                        protected String accessorySubType;

                        /**
                         * Gets the value of the lastActivationDate property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public XMLGregorianCalendar getLastActivationDate() {
                            return lastActivationDate;
                        }

                        /**
                         * Sets the value of the lastActivationDate property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link XMLGregorianCalendar }
                         *     
                         */
                        public void setLastActivationDate(XMLGregorianCalendar value) {
                            this.lastActivationDate = value;
                        }

                        /**
                         * Gets the value of the accessorySubType property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getAccessorySubType() {
                            return accessorySubType;
                        }

                        /**
                         * Sets the value of the accessorySubType property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setAccessorySubType(String value) {
                            this.accessorySubType = value;
                        }

                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="SubscriptionItem" maxOccurs="unbounded" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="SubscriptionServiceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="SubscriptionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="ServiceStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="DescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="DescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "subscriptionItem"
            })
            public static class Item {

                @XmlElement(name = "SubscriptionItem")
                protected List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem> subscriptionItem;

                /**
                 * Gets the value of the subscriptionItem property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the subscriptionItem property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getSubscriptionItem().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem }
                 * 
                 * 
                 */
                public List<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem> getSubscriptionItem() {
                    if (subscriptionItem == null) {
                        subscriptionItem = new ArrayList<RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem>();
                    }
                    return this.subscriptionItem;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="SubscriptionServiceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="SubscriptionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="ServiceStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="DescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="DescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "subscriptionServiceIdentifier",
                    "subscriptionType",
                    "serviceStartDate",
                    "descriptionEn",
                    "descriptionFr"
                })
                public static class SubscriptionItem {

                    @XmlElement(name = "SubscriptionServiceIdentifier", required = true)
                    protected String subscriptionServiceIdentifier;
                    @XmlElement(name = "SubscriptionType", required = true)
                    protected String subscriptionType;
                    @XmlElement(name = "ServiceStartDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar serviceStartDate;
                    @XmlElement(name = "DescriptionEn")
                    protected String descriptionEn;
                    @XmlElement(name = "DescriptionFr")
                    protected String descriptionFr;

                    /**
                     * Gets the value of the subscriptionServiceIdentifier property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getSubscriptionServiceIdentifier() {
                        return subscriptionServiceIdentifier;
                    }

                    /**
                     * Sets the value of the subscriptionServiceIdentifier property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setSubscriptionServiceIdentifier(String value) {
                        this.subscriptionServiceIdentifier = value;
                    }

                    /**
                     * Gets the value of the subscriptionType property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getSubscriptionType() {
                        return subscriptionType;
                    }

                    /**
                     * Sets the value of the subscriptionType property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setSubscriptionType(String value) {
                        this.subscriptionType = value;
                    }

                    /**
                     * Gets the value of the serviceStartDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getServiceStartDate() {
                        return serviceStartDate;
                    }

                    /**
                     * Sets the value of the serviceStartDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setServiceStartDate(XMLGregorianCalendar value) {
                        this.serviceStartDate = value;
                    }

                    /**
                     * Gets the value of the descriptionEn property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDescriptionEn() {
                        return descriptionEn;
                    }

                    /**
                     * Sets the value of the descriptionEn property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDescriptionEn(String value) {
                        this.descriptionEn = value;
                    }

                    /**
                     * Gets the value of the descriptionFr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDescriptionFr() {
                        return descriptionFr;
                    }

                    /**
                     * Sets the value of the descriptionFr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDescriptionFr(String value) {
                        this.descriptionFr = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ProgrammingPlatform" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "accountType",
                "programmingPlatform"
            })
            public static class SubscriptionHeader {

                @XmlElement(name = "AccountType", required = true)
                protected String accountType;
                @XmlElement(name = "ProgrammingPlatform")
                protected String programmingPlatform;

                /**
                 * Gets the value of the accountType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAccountType() {
                    return accountType;
                }

                /**
                 * Sets the value of the accountType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAccountType(String value) {
                    this.accountType = value;
                }

                /**
                 * Gets the value of the programmingPlatform property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getProgrammingPlatform() {
                    return programmingPlatform;
                }

                /**
                 * Sets the value of the programmingPlatform property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setProgrammingPlatform(String value) {
                    this.programmingPlatform = value;
                }

            }

        }

    }

}
