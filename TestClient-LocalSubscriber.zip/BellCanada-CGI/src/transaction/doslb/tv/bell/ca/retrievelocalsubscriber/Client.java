package transaction.doslb.tv.bell.ca.retrievelocalsubscriber;
import java.io.*;
import java.net.*;
import javax.xml.namespace.*;

public class Client 
  {
  public static void main(String args[]) throws Exception 
    {
    URL wsdlURL = new URL("file:wsdl/retrieveLocalSubscriberTransaction.wsdl");

    RetrieveLocalSubscriberTransactionService service = new RetrieveLocalSubscriberTransactionService(wsdlURL, 
      RetrieveLocalSubscriberTransactionService.SERVICE);

    // TestmePort is a Java interface that defines the service port's
    //  inputs and outputs; generated from the WSDL file by wsdl2java
    RetrieveLocalSubscriberTransaction port = service.getPort(RetrieveLocalSubscriberTransactionService.RetrieveLocalSubscriberTransactionSoap11, 
      RetrieveLocalSubscriberTransaction.class);

    System.out.println("Invoking retrieveLocalSubscriber");

    // The name testMe() comes from the definition of the port type in
    //  the WSDL file:
    //  <wsdl:portType name="testmePort">
    //    <wsdl:operation name="testMe">
    RetrieveLocalSubscriberRequest req = new RetrieveLocalSubscriberRequest();
    req.setCSGAccountNumber("123");
    req.setApplicationId("Test");
    RetrieveLocalSubscriberRequest.SectionsRequired sec = req.getSectionsRequired();

    sec.getSection().add("SU");
    sec.getSection().add("SI");
    sec.getSection().add("EQ");
    sec.getSection().add("CO");
    sec.getSection().add("IN");
    sec.getSection().add("IN2");
    sec.getSection().add("AC");
    sec.getSection().add("XE");
    sec.getSection().add("BBM");
    
    RetrieveLocalSubscriberResponse res  = port.retrieveLocalSubscriber(req);
    System.out.println("Server responded with: " + res);
    System.out.println();
    }
  }

