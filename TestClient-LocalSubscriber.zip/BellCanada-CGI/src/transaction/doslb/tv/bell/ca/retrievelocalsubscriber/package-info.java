@javax.xml.bind.annotation.XmlSchema(namespace = "http://ca.bell.tv.doslb.transaction/RetrieveLocalSubscriber", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package transaction.doslb.tv.bell.ca.retrievelocalsubscriber;
