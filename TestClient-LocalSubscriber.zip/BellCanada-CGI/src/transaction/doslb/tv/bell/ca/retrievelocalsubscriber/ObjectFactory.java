
package transaction.doslb.tv.bell.ca.retrievelocalsubscriber;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the transaction.doslb.tv.bell.ca.retrievelocalsubscriber package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: transaction.doslb.tv.bell.ca.retrievelocalsubscriber
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse }
     * 
     */
    public RetrieveLocalSubscriberResponse createRetrieveLocalSubscriberResponse() {
        return new RetrieveLocalSubscriberResponse();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberRequest }
     * 
     */
    public RetrieveLocalSubscriberRequest createRetrieveLocalSubscriberRequest() {
        return new RetrieveLocalSubscriberRequest();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.ResponseInfo }
     * 
     */
    public RetrieveLocalSubscriberResponse.ResponseInfo createRetrieveLocalSubscriberResponseResponseInfo() {
        return new RetrieveLocalSubscriberResponse.ResponseInfo();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages }
     * 
     */
    public RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages createRetrieveLocalSubscriberResponseResponseInfoErrorMessages() {
        return new RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber createRetrieveLocalSubscriberResponseSubscriber() {
        return new RetrieveLocalSubscriberResponse.Subscriber();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 createRetrieveLocalSubscriberResponseSubscriberChargeInstalments2() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments createRetrieveLocalSubscriberResponseSubscriberChargeInstalments() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription createRetrieveLocalSubscriberResponseSubscriberSubscription() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract createRetrieveLocalSubscriberResponseSubscriberSubscriptionContract() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment createRetrieveLocalSubscriberResponseSubscriberSubscriptionContractEquipment() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account createRetrieveLocalSubscriberResponseSubscriberSubscriptionContractAccount() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment createRetrieveLocalSubscriberResponseSubscriberSubscriptionEquipment() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment createRetrieveLocalSubscriberResponseSubscriberSubscriptionEquipmentSubscriptionEquipment() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item createRetrieveLocalSubscriberResponseSubscriberSubscriptionItem() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation createRetrieveLocalSubscriberResponseSubscriberServiceLocation() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader createRetrieveLocalSubscriberResponseSubscriberSubscriberHeader() {
        return new RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes createRetrieveLocalSubscriberResponseSubscriberSubscriberHeaderExtendedAttributes() {
        return new RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities createRetrieveLocalSubscriberResponseSubscriberSubscriberHeaderExtendedAttributesIdentities() {
        return new RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberRequest.SectionsRequired }
     * 
     */
    public RetrieveLocalSubscriberRequest.SectionsRequired createRetrieveLocalSubscriberRequestSectionsRequired() {
        return new RetrieveLocalSubscriberRequest.SectionsRequired();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage }
     * 
     */
    public RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage createRetrieveLocalSubscriberResponseResponseInfoErrorMessagesErrorMessage() {
        return new RetrieveLocalSubscriberResponse.ResponseInfo.ErrorMessages.ErrorMessage();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment createRetrieveLocalSubscriberResponseSubscriberChargeInstalments2ChargeInstalment() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments2 .ChargeInstalment();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment createRetrieveLocalSubscriberResponseSubscriberChargeInstalmentsChargeInstalment() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ChargeInstalments.ChargeInstalment();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader createRetrieveLocalSubscriberResponseSubscriberSubscriptionSubscriptionHeader() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.SubscriptionHeader();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources createRetrieveLocalSubscriberResponseSubscriberSubscriptionAssignedResources() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.AssignedResources();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement createRetrieveLocalSubscriberResponseSubscriberSubscriptionContractEquipmentEquipmentAgreement() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Equipment.EquipmentAgreement();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement createRetrieveLocalSubscriberResponseSubscriberSubscriptionContractAccountAccountAgreement() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Contract.Account.AccountAgreement();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes createRetrieveLocalSubscriberResponseSubscriberSubscriptionEquipmentSubscriptionEquipmentExtendedAttributes() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Equipment.SubscriptionEquipment.ExtendedAttributes();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem createRetrieveLocalSubscriberResponseSubscriberSubscriptionItemSubscriptionItem() {
        return new RetrieveLocalSubscriberResponse.Subscriber.Subscription.Item.SubscriptionItem();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress createRetrieveLocalSubscriberResponseSubscriberServiceLocationServiceAddress() {
        return new RetrieveLocalSubscriberResponse.Subscriber.ServiceLocation.ServiceAddress();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos createRetrieveLocalSubscriberResponseSubscriberSubscriberHeaderExtendedAttributesControlInfos() {
        return new RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.ControlInfos();
    }

    /**
     * Create an instance of {@link RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType }
     * 
     */
    public RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType createRetrieveLocalSubscriberResponseSubscriberSubscriberHeaderExtendedAttributesIdentitiesCustomerType() {
        return new RetrieveLocalSubscriberResponse.Subscriber.SubscriberHeader.ExtendedAttributes.Identities.CustomerType();
    }

}
