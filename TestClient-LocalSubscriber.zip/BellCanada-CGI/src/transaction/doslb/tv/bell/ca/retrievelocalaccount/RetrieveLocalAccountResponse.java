
package transaction.doslb.tv.bell.ca.retrievelocalaccount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BillAccount" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="AccountHeader" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="AccountStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="AccountConnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                             &lt;element name="AccountDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                             &lt;element name="ExtendedAttributes" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Identities" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="CustomerType" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                                         &lt;sequence>
 *                                                           &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                                           &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                         &lt;/sequence>
 *                                                       &lt;/restriction>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element name="ControlInfos" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="AccountAddress" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Salutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Invoice" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="BillCycleDay" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                             &lt;element name="BillingLanguage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="BTVCustomer" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="CustomerIdentification">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="HomePhone" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="WorkPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="AccountProduct" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ProductHeader">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ProductCode" maxOccurs="unbounded" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="Discount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Promotions" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PromotionDetails" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="PromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="SubPromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="PromotionDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="PromotionDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="SubPromoDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="SubPromoDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="QualificationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="QualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="DisqualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="TotalPaymentCycles" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="CreditstoBePaidEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="CreditstoBePaidFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="DisqalificationReasonEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="DisqalificationReasonFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="LastCreditAmountPaid" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Contract" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Account" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="AccountAgreement">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Equipment" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                                 &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                                 &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="ChargeInstalments" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="ChargeInstalments2" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                                       &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *                                       &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                                       &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ResponseInfo">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SystemCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="SystemMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="TransactionId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="ErrorMessages" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ErrorMessage" maxOccurs="unbounded">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "billAccount",
    "responseInfo"
})
@XmlRootElement(name = "RetrieveLocalAccountResponse")
public class RetrieveLocalAccountResponse {

    @XmlElement(name = "BillAccount")
    protected RetrieveLocalAccountResponse.BillAccount billAccount;
    @XmlElement(name = "ResponseInfo", required = true)
    protected RetrieveLocalAccountResponse.ResponseInfo responseInfo;

    /**
     * Gets the value of the billAccount property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveLocalAccountResponse.BillAccount }
     *     
     */
    public RetrieveLocalAccountResponse.BillAccount getBillAccount() {
        return billAccount;
    }

    /**
     * Sets the value of the billAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveLocalAccountResponse.BillAccount }
     *     
     */
    public void setBillAccount(RetrieveLocalAccountResponse.BillAccount value) {
        this.billAccount = value;
    }

    /**
     * Gets the value of the responseInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveLocalAccountResponse.ResponseInfo }
     *     
     */
    public RetrieveLocalAccountResponse.ResponseInfo getResponseInfo() {
        return responseInfo;
    }

    /**
     * Sets the value of the responseInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveLocalAccountResponse.ResponseInfo }
     *     
     */
    public void setResponseInfo(RetrieveLocalAccountResponse.ResponseInfo value) {
        this.responseInfo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="AccountHeader" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="AccountStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="AccountConnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                   &lt;element name="AccountDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                   &lt;element name="ExtendedAttributes" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Identities" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="CustomerType" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                               &lt;sequence>
     *                                                 &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                                                 &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                               &lt;/sequence>
     *                                             &lt;/restriction>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element name="ControlInfos" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="AccountAddress" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Salutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Invoice" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="BillCycleDay" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                   &lt;element name="BillingLanguage" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="BTVCustomer" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="CustomerIdentification">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="HomePhone" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="WorkPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="AccountProduct" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ProductHeader">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="ProductCode" maxOccurs="unbounded" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="Discount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Promotions" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="PromotionDetails" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="PromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="SubPromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="PromotionDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="PromotionDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="SubPromoDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="SubPromoDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="QualificationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="QualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="DisqualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="TotalPaymentCycles" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="CreditstoBePaidEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="CreditstoBePaidFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="DisqalificationReasonEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="DisqalificationReasonFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="LastCreditAmountPaid" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Contract" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Account" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="AccountAgreement">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Equipment" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                       &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                                       &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="ChargeInstalments" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="ChargeInstalments2" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                             &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
     *                             &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                             &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "accountHeader",
        "accountAddress",
        "invoice",
        "btvCustomer",
        "accountProduct",
        "promotions",
        "contract",
        "chargeInstalments",
        "chargeInstalments2"
    })
    public static class BillAccount {

        @XmlElement(name = "AccountHeader")
        protected RetrieveLocalAccountResponse.BillAccount.AccountHeader accountHeader;
        @XmlElement(name = "AccountAddress")
        protected RetrieveLocalAccountResponse.BillAccount.AccountAddress accountAddress;
        @XmlElement(name = "Invoice")
        protected RetrieveLocalAccountResponse.BillAccount.Invoice invoice;
        @XmlElement(name = "BTVCustomer")
        protected RetrieveLocalAccountResponse.BillAccount.BTVCustomer btvCustomer;
        @XmlElement(name = "AccountProduct")
        protected RetrieveLocalAccountResponse.BillAccount.AccountProduct accountProduct;
        @XmlElement(name = "Promotions")
        protected RetrieveLocalAccountResponse.BillAccount.Promotions promotions;
        @XmlElement(name = "Contract")
        protected RetrieveLocalAccountResponse.BillAccount.Contract contract;
        @XmlElement(name = "ChargeInstalments")
        protected RetrieveLocalAccountResponse.BillAccount.ChargeInstalments chargeInstalments;
        @XmlElement(name = "ChargeInstalments2")
        protected RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 chargeInstalments2;

        /**
         * Gets the value of the accountHeader property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.AccountHeader getAccountHeader() {
            return accountHeader;
        }

        /**
         * Sets the value of the accountHeader property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader }
         *     
         */
        public void setAccountHeader(RetrieveLocalAccountResponse.BillAccount.AccountHeader value) {
            this.accountHeader = value;
        }

        /**
         * Gets the value of the accountAddress property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountAddress }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.AccountAddress getAccountAddress() {
            return accountAddress;
        }

        /**
         * Sets the value of the accountAddress property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountAddress }
         *     
         */
        public void setAccountAddress(RetrieveLocalAccountResponse.BillAccount.AccountAddress value) {
            this.accountAddress = value;
        }

        /**
         * Gets the value of the invoice property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Invoice }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.Invoice getInvoice() {
            return invoice;
        }

        /**
         * Sets the value of the invoice property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Invoice }
         *     
         */
        public void setInvoice(RetrieveLocalAccountResponse.BillAccount.Invoice value) {
            this.invoice = value;
        }

        /**
         * Gets the value of the btvCustomer property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.BTVCustomer getBTVCustomer() {
            return btvCustomer;
        }

        /**
         * Sets the value of the btvCustomer property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer }
         *     
         */
        public void setBTVCustomer(RetrieveLocalAccountResponse.BillAccount.BTVCustomer value) {
            this.btvCustomer = value;
        }

        /**
         * Gets the value of the accountProduct property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.AccountProduct getAccountProduct() {
            return accountProduct;
        }

        /**
         * Sets the value of the accountProduct property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct }
         *     
         */
        public void setAccountProduct(RetrieveLocalAccountResponse.BillAccount.AccountProduct value) {
            this.accountProduct = value;
        }

        /**
         * Gets the value of the promotions property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Promotions }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.Promotions getPromotions() {
            return promotions;
        }

        /**
         * Sets the value of the promotions property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Promotions }
         *     
         */
        public void setPromotions(RetrieveLocalAccountResponse.BillAccount.Promotions value) {
            this.promotions = value;
        }

        /**
         * Gets the value of the contract property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Contract }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.Contract getContract() {
            return contract;
        }

        /**
         * Sets the value of the contract property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.Contract }
         *     
         */
        public void setContract(RetrieveLocalAccountResponse.BillAccount.Contract value) {
            this.contract = value;
        }

        /**
         * Gets the value of the chargeInstalments property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments getChargeInstalments() {
            return chargeInstalments;
        }

        /**
         * Sets the value of the chargeInstalments property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments }
         *     
         */
        public void setChargeInstalments(RetrieveLocalAccountResponse.BillAccount.ChargeInstalments value) {
            this.chargeInstalments = value;
        }

        /**
         * Gets the value of the chargeInstalments2 property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 }
         *     
         */
        public RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 getChargeInstalments2() {
            return chargeInstalments2;
        }

        /**
         * Sets the value of the chargeInstalments2 property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 }
         *     
         */
        public void setChargeInstalments2(RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 value) {
            this.chargeInstalments2 = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Salutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="ProvinceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "salutation",
            "firstName",
            "lastName",
            "address1",
            "address2",
            "city",
            "postalCode",
            "provinceCode",
            "countryCode"
        })
        public static class AccountAddress {

            @XmlElement(name = "Salutation")
            protected String salutation;
            @XmlElement(name = "FirstName")
            protected String firstName;
            @XmlElement(name = "LastName")
            protected String lastName;
            @XmlElement(name = "Address1")
            protected String address1;
            @XmlElement(name = "Address2")
            protected String address2;
            @XmlElement(name = "City")
            protected String city;
            @XmlElement(name = "PostalCode")
            protected String postalCode;
            @XmlElement(name = "ProvinceCode")
            protected String provinceCode;
            @XmlElement(name = "CountryCode")
            protected String countryCode;

            /**
             * Gets the value of the salutation property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSalutation() {
                return salutation;
            }

            /**
             * Sets the value of the salutation property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSalutation(String value) {
                this.salutation = value;
            }

            /**
             * Gets the value of the firstName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFirstName() {
                return firstName;
            }

            /**
             * Sets the value of the firstName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFirstName(String value) {
                this.firstName = value;
            }

            /**
             * Gets the value of the lastName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLastName() {
                return lastName;
            }

            /**
             * Sets the value of the lastName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLastName(String value) {
                this.lastName = value;
            }

            /**
             * Gets the value of the address1 property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getAddress1() {
                return address1;
            }

            /**
             * Sets the value of the address1 property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setAddress1(String value) {
                this.address1 = value;
            }

            /**
             * Gets the value of the address2 property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getAddress2() {
                return address2;
            }

            /**
             * Sets the value of the address2 property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setAddress2(String value) {
                this.address2 = value;
            }

            /**
             * Gets the value of the city property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCity() {
                return city;
            }

            /**
             * Sets the value of the city property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCity(String value) {
                this.city = value;
            }

            /**
             * Gets the value of the postalCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPostalCode() {
                return postalCode;
            }

            /**
             * Sets the value of the postalCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPostalCode(String value) {
                this.postalCode = value;
            }

            /**
             * Gets the value of the provinceCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getProvinceCode() {
                return provinceCode;
            }

            /**
             * Sets the value of the provinceCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setProvinceCode(String value) {
                this.provinceCode = value;
            }

            /**
             * Gets the value of the countryCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCountryCode() {
                return countryCode;
            }

            /**
             * Sets the value of the countryCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCountryCode(String value) {
                this.countryCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="CSGAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="AccountStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="AccountConnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *         &lt;element name="AccountDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *         &lt;element name="ExtendedAttributes" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Identities" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="CustomerType" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                                     &lt;sequence>
         *                                       &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                                       &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                                     &lt;/sequence>
         *                                   &lt;/restriction>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element name="ControlInfos" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "csgAccountNumber",
            "accountType",
            "accountStatus",
            "accountConnectDate",
            "accountDisconnectDate",
            "extendedAttributes"
        })
        public static class AccountHeader {

            @XmlElement(name = "CSGAccountNumber", required = true)
            protected String csgAccountNumber;
            @XmlElement(name = "AccountType", required = true)
            protected String accountType;
            @XmlElement(name = "AccountStatus", required = true)
            protected String accountStatus;
            @XmlElement(name = "AccountConnectDate")
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar accountConnectDate;
            @XmlElement(name = "AccountDisconnectDate")
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar accountDisconnectDate;
            @XmlElement(name = "ExtendedAttributes")
            protected RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes extendedAttributes;

            /**
             * Gets the value of the csgAccountNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCSGAccountNumber() {
                return csgAccountNumber;
            }

            /**
             * Sets the value of the csgAccountNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCSGAccountNumber(String value) {
                this.csgAccountNumber = value;
            }

            /**
             * Gets the value of the accountType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getAccountType() {
                return accountType;
            }

            /**
             * Sets the value of the accountType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setAccountType(String value) {
                this.accountType = value;
            }

            /**
             * Gets the value of the accountStatus property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getAccountStatus() {
                return accountStatus;
            }

            /**
             * Sets the value of the accountStatus property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setAccountStatus(String value) {
                this.accountStatus = value;
            }

            /**
             * Gets the value of the accountConnectDate property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getAccountConnectDate() {
                return accountConnectDate;
            }

            /**
             * Sets the value of the accountConnectDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setAccountConnectDate(XMLGregorianCalendar value) {
                this.accountConnectDate = value;
            }

            /**
             * Gets the value of the accountDisconnectDate property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getAccountDisconnectDate() {
                return accountDisconnectDate;
            }

            /**
             * Sets the value of the accountDisconnectDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setAccountDisconnectDate(XMLGregorianCalendar value) {
                this.accountDisconnectDate = value;
            }

            /**
             * Gets the value of the extendedAttributes property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes }
             *     
             */
            public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes getExtendedAttributes() {
                return extendedAttributes;
            }

            /**
             * Sets the value of the extendedAttributes property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes }
             *     
             */
            public void setExtendedAttributes(RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes value) {
                this.extendedAttributes = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Identities" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="CustomerType" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                           &lt;sequence>
             *                             &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *                             &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                           &lt;/sequence>
             *                         &lt;/restriction>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element name="ControlInfos" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "identities",
                "controlInfos"
            })
            public static class ExtendedAttributes {

                @XmlElement(name = "Identities")
                protected RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities identities;
                @XmlElement(name = "ControlInfos")
                protected RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos controlInfos;

                /**
                 * Gets the value of the identities property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities }
                 *     
                 */
                public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities getIdentities() {
                    return identities;
                }

                /**
                 * Sets the value of the identities property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities }
                 *     
                 */
                public void setIdentities(RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities value) {
                    this.identities = value;
                }

                /**
                 * Gets the value of the controlInfos property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos }
                 *     
                 */
                public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos getControlInfos() {
                    return controlInfos;
                }

                /**
                 * Sets the value of the controlInfos property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos }
                 *     
                 */
                public void setControlInfos(RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.ControlInfos value) {
                    this.controlInfos = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="SeatingCapacity" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "seatingCapacity"
                })
                public static class ControlInfos {

                    @XmlElement(name = "SeatingCapacity")
                    protected Integer seatingCapacity;

                    /**
                     * Gets the value of the seatingCapacity property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link Integer }
                     *     
                     */
                    public Integer getSeatingCapacity() {
                        return seatingCapacity;
                    }

                    /**
                     * Sets the value of the seatingCapacity property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link Integer }
                     *     
                     */
                    public void setSeatingCapacity(Integer value) {
                        this.seatingCapacity = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="B1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="NM1BAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="CustomerType" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *                 &lt;sequence>
                 *                   &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                 *                   &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *                 &lt;/sequence>
                 *               &lt;/restriction>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "b1",
                    "nm1BAN",
                    "customerType"
                })
                public static class Identities {

                    @XmlElement(name = "B1")
                    protected String b1;
                    @XmlElement(name = "NM1BAN")
                    protected String nm1BAN;
                    @XmlElement(name = "CustomerType")
                    protected RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType customerType;

                    /**
                     * Gets the value of the b1 property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getB1() {
                        return b1;
                    }

                    /**
                     * Sets the value of the b1 property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setB1(String value) {
                        this.b1 = value;
                    }

                    /**
                     * Gets the value of the nm1BAN property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getNM1BAN() {
                        return nm1BAN;
                    }

                    /**
                     * Sets the value of the nm1BAN property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setNM1BAN(String value) {
                        this.nm1BAN = value;
                    }

                    /**
                     * Gets the value of the customerType property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType }
                     *     
                     */
                    public RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType getCustomerType() {
                        return customerType;
                    }

                    /**
                     * Sets the value of the customerType property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType }
                     *     
                     */
                    public void setCustomerType(RetrieveLocalAccountResponse.BillAccount.AccountHeader.ExtendedAttributes.Identities.CustomerType value) {
                        this.customerType = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                     *       &lt;sequence>
                     *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
                     *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                     *       &lt;/sequence>
                     *     &lt;/restriction>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "id",
                        "description"
                    })
                    public static class CustomerType {

                        @XmlElement(name = "ID")
                        protected Integer id;
                        @XmlElement(name = "Description")
                        protected String description;

                        /**
                         * Gets the value of the id property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link Integer }
                         *     
                         */
                        public Integer getID() {
                            return id;
                        }

                        /**
                         * Sets the value of the id property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link Integer }
                         *     
                         */
                        public void setID(Integer value) {
                            this.id = value;
                        }

                        /**
                         * Gets the value of the description property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDescription() {
                            return description;
                        }

                        /**
                         * Sets the value of the description property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDescription(String value) {
                            this.description = value;
                        }

                    }

                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ProductHeader">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="ProductCode" maxOccurs="unbounded" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="Discount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "productHeader"
        })
        public static class AccountProduct {

            @XmlElement(name = "ProductHeader", required = true)
            protected RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader productHeader;

            /**
             * Gets the value of the productHeader property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader }
             *     
             */
            public RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader getProductHeader() {
                return productHeader;
            }

            /**
             * Sets the value of the productHeader property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader }
             *     
             */
            public void setProductHeader(RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader value) {
                this.productHeader = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="ProductCode" maxOccurs="unbounded" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="Discount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "productCode"
            })
            public static class ProductHeader {

                @XmlElement(name = "ProductCode")
                protected List<RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode> productCode;

                /**
                 * Gets the value of the productCode property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the productCode property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getProductCode().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode }
                 * 
                 * 
                 */
                public List<RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode> getProductCode() {
                    if (productCode == null) {
                        productCode = new ArrayList<RetrieveLocalAccountResponse.BillAccount.AccountProduct.ProductHeader.ProductCode>();
                    }
                    return this.productCode;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
                 *         &lt;element name="Discount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}int"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "code",
                    "discount",
                    "quantity"
                })
                public static class ProductCode {

                    @XmlElement(name = "Code", required = true)
                    protected String code;
                    @XmlElement(name = "Discount")
                    protected String discount;
                    @XmlElement(name = "Quantity")
                    protected int quantity;

                    /**
                     * Gets the value of the code property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCode() {
                        return code;
                    }

                    /**
                     * Sets the value of the code property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCode(String value) {
                        this.code = value;
                    }

                    /**
                     * Gets the value of the discount property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDiscount() {
                        return discount;
                    }

                    /**
                     * Sets the value of the discount property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDiscount(String value) {
                        this.discount = value;
                    }

                    /**
                     * Gets the value of the quantity property.
                     * 
                     */
                    public int getQuantity() {
                        return quantity;
                    }

                    /**
                     * Sets the value of the quantity property.
                     * 
                     */
                    public void setQuantity(int value) {
                        this.quantity = value;
                    }

                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="CustomerIdentification">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="HomePhone" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="WorkPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "customerIdentification"
        })
        public static class BTVCustomer {

            @XmlElement(name = "CustomerIdentification", required = true)
            protected RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification customerIdentification;

            /**
             * Gets the value of the customerIdentification property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification }
             *     
             */
            public RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification getCustomerIdentification() {
                return customerIdentification;
            }

            /**
             * Sets the value of the customerIdentification property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification }
             *     
             */
            public void setCustomerIdentification(RetrieveLocalAccountResponse.BillAccount.BTVCustomer.CustomerIdentification value) {
                this.customerIdentification = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="HomePhone" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="WorkPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "homePhone",
                "workPhone",
                "fullName"
            })
            public static class CustomerIdentification {

                @XmlElement(name = "HomePhone", required = true)
                protected String homePhone;
                @XmlElement(name = "WorkPhone")
                protected String workPhone;
                @XmlElement(name = "FullName")
                protected String fullName;

                /**
                 * Gets the value of the homePhone property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getHomePhone() {
                    return homePhone;
                }

                /**
                 * Sets the value of the homePhone property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setHomePhone(String value) {
                    this.homePhone = value;
                }

                /**
                 * Gets the value of the workPhone property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getWorkPhone() {
                    return workPhone;
                }

                /**
                 * Sets the value of the workPhone property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setWorkPhone(String value) {
                    this.workPhone = value;
                }

                /**
                 * Gets the value of the fullName property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFullName() {
                    return fullName;
                }

                /**
                 * Sets the value of the fullName property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFullName(String value) {
                    this.fullName = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargeInstalment"
        })
        public static class ChargeInstalments {

            @XmlElement(name = "ChargeInstalment")
            protected List<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment> chargeInstalment;

            /**
             * Gets the value of the chargeInstalment property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the chargeInstalment property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getChargeInstalment().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment }
             * 
             * 
             */
            public List<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment> getChargeInstalment() {
                if (chargeInstalment == null) {
                    chargeInstalment = new ArrayList<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments.ChargeInstalment>();
                }
                return this.chargeInstalment;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "totalAmount",
                "monthlyCharge",
                "totalAmountCharged",
                "totalNumberOfCharges",
                "numberOfChargesSent",
                "numberOfChargesRemaining",
                "balance",
                "equipmentIdentifier",
                "instalmentStartDate",
                "instalmentEndDate"
            })
            public static class ChargeInstalment {

                @XmlElement(name = "TotalAmount")
                protected BigDecimal totalAmount;
                @XmlElement(name = "MonthlyCharge")
                protected BigDecimal monthlyCharge;
                @XmlElement(name = "TotalAmountCharged")
                protected BigDecimal totalAmountCharged;
                @XmlElement(name = "TotalNumberOfCharges")
                protected Integer totalNumberOfCharges;
                @XmlElement(name = "NumberOfChargesSent")
                protected Integer numberOfChargesSent;
                @XmlElement(name = "NumberOfChargesRemaining")
                protected Integer numberOfChargesRemaining;
                @XmlElement(name = "Balance")
                protected BigDecimal balance;
                @XmlElement(name = "EquipmentIdentifier")
                protected String equipmentIdentifier;
                @XmlElement(name = "InstalmentStartDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentStartDate;
                @XmlElement(name = "InstalmentEndDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentEndDate;

                /**
                 * Gets the value of the totalAmount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmount() {
                    return totalAmount;
                }

                /**
                 * Sets the value of the totalAmount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmount(BigDecimal value) {
                    this.totalAmount = value;
                }

                /**
                 * Gets the value of the monthlyCharge property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getMonthlyCharge() {
                    return monthlyCharge;
                }

                /**
                 * Sets the value of the monthlyCharge property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setMonthlyCharge(BigDecimal value) {
                    this.monthlyCharge = value;
                }

                /**
                 * Gets the value of the totalAmountCharged property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmountCharged() {
                    return totalAmountCharged;
                }

                /**
                 * Sets the value of the totalAmountCharged property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmountCharged(BigDecimal value) {
                    this.totalAmountCharged = value;
                }

                /**
                 * Gets the value of the totalNumberOfCharges property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getTotalNumberOfCharges() {
                    return totalNumberOfCharges;
                }

                /**
                 * Sets the value of the totalNumberOfCharges property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setTotalNumberOfCharges(Integer value) {
                    this.totalNumberOfCharges = value;
                }

                /**
                 * Gets the value of the numberOfChargesSent property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesSent() {
                    return numberOfChargesSent;
                }

                /**
                 * Sets the value of the numberOfChargesSent property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesSent(Integer value) {
                    this.numberOfChargesSent = value;
                }

                /**
                 * Gets the value of the numberOfChargesRemaining property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesRemaining() {
                    return numberOfChargesRemaining;
                }

                /**
                 * Sets the value of the numberOfChargesRemaining property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesRemaining(Integer value) {
                    this.numberOfChargesRemaining = value;
                }

                /**
                 * Gets the value of the balance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getBalance() {
                    return balance;
                }

                /**
                 * Sets the value of the balance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setBalance(BigDecimal value) {
                    this.balance = value;
                }

                /**
                 * Gets the value of the equipmentIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getEquipmentIdentifier() {
                    return equipmentIdentifier;
                }

                /**
                 * Sets the value of the equipmentIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setEquipmentIdentifier(String value) {
                    this.equipmentIdentifier = value;
                }

                /**
                 * Gets the value of the instalmentStartDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentStartDate() {
                    return instalmentStartDate;
                }

                /**
                 * Sets the value of the instalmentStartDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentStartDate(XMLGregorianCalendar value) {
                    this.instalmentStartDate = value;
                }

                /**
                 * Gets the value of the instalmentEndDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentEndDate() {
                    return instalmentEndDate;
                }

                /**
                 * Sets the value of the instalmentEndDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentEndDate(XMLGregorianCalendar value) {
                    this.instalmentEndDate = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ChargeInstalment" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                   &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargeInstalment"
        })
        public static class ChargeInstalments2 {

            @XmlElement(name = "ChargeInstalment")
            protected List<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment> chargeInstalment;

            /**
             * Gets the value of the chargeInstalment property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the chargeInstalment property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getChargeInstalment().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment }
             * 
             * 
             */
            public List<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment> getChargeInstalment() {
                if (chargeInstalment == null) {
                    chargeInstalment = new ArrayList<RetrieveLocalAccountResponse.BillAccount.ChargeInstalments2 .ChargeInstalment>();
                }
                return this.chargeInstalment;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="TotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="MonthlyCharge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalAmountCharged" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="TotalNumberOfCharges" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesSent" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="NumberOfChargesRemaining" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *         &lt;element name="EquipmentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="InstalmentDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="InstalmentDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "totalAmount",
                "monthlyCharge",
                "totalAmountCharged",
                "totalNumberOfCharges",
                "numberOfChargesSent",
                "numberOfChargesRemaining",
                "balance",
                "equipmentIdentifier",
                "instalmentStartDate",
                "instalmentEndDate",
                "instalmentDescriptionEn",
                "instalmentDescriptionFr"
            })
            public static class ChargeInstalment {

                @XmlElement(name = "TotalAmount")
                protected BigDecimal totalAmount;
                @XmlElement(name = "MonthlyCharge")
                protected BigDecimal monthlyCharge;
                @XmlElement(name = "TotalAmountCharged")
                protected BigDecimal totalAmountCharged;
                @XmlElement(name = "TotalNumberOfCharges")
                protected Integer totalNumberOfCharges;
                @XmlElement(name = "NumberOfChargesSent")
                protected Integer numberOfChargesSent;
                @XmlElement(name = "NumberOfChargesRemaining")
                protected Integer numberOfChargesRemaining;
                @XmlElement(name = "Balance")
                protected BigDecimal balance;
                @XmlElement(name = "EquipmentIdentifier")
                protected String equipmentIdentifier;
                @XmlElement(name = "InstalmentStartDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentStartDate;
                @XmlElement(name = "InstalmentEndDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar instalmentEndDate;
                @XmlElement(name = "InstalmentDescriptionEn")
                protected String instalmentDescriptionEn;
                @XmlElement(name = "InstalmentDescriptionFr")
                protected String instalmentDescriptionFr;

                /**
                 * Gets the value of the totalAmount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmount() {
                    return totalAmount;
                }

                /**
                 * Sets the value of the totalAmount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmount(BigDecimal value) {
                    this.totalAmount = value;
                }

                /**
                 * Gets the value of the monthlyCharge property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getMonthlyCharge() {
                    return monthlyCharge;
                }

                /**
                 * Sets the value of the monthlyCharge property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setMonthlyCharge(BigDecimal value) {
                    this.monthlyCharge = value;
                }

                /**
                 * Gets the value of the totalAmountCharged property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getTotalAmountCharged() {
                    return totalAmountCharged;
                }

                /**
                 * Sets the value of the totalAmountCharged property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setTotalAmountCharged(BigDecimal value) {
                    this.totalAmountCharged = value;
                }

                /**
                 * Gets the value of the totalNumberOfCharges property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getTotalNumberOfCharges() {
                    return totalNumberOfCharges;
                }

                /**
                 * Sets the value of the totalNumberOfCharges property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setTotalNumberOfCharges(Integer value) {
                    this.totalNumberOfCharges = value;
                }

                /**
                 * Gets the value of the numberOfChargesSent property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesSent() {
                    return numberOfChargesSent;
                }

                /**
                 * Sets the value of the numberOfChargesSent property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesSent(Integer value) {
                    this.numberOfChargesSent = value;
                }

                /**
                 * Gets the value of the numberOfChargesRemaining property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getNumberOfChargesRemaining() {
                    return numberOfChargesRemaining;
                }

                /**
                 * Sets the value of the numberOfChargesRemaining property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setNumberOfChargesRemaining(Integer value) {
                    this.numberOfChargesRemaining = value;
                }

                /**
                 * Gets the value of the balance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getBalance() {
                    return balance;
                }

                /**
                 * Sets the value of the balance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setBalance(BigDecimal value) {
                    this.balance = value;
                }

                /**
                 * Gets the value of the equipmentIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getEquipmentIdentifier() {
                    return equipmentIdentifier;
                }

                /**
                 * Sets the value of the equipmentIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setEquipmentIdentifier(String value) {
                    this.equipmentIdentifier = value;
                }

                /**
                 * Gets the value of the instalmentStartDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentStartDate() {
                    return instalmentStartDate;
                }

                /**
                 * Sets the value of the instalmentStartDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentStartDate(XMLGregorianCalendar value) {
                    this.instalmentStartDate = value;
                }

                /**
                 * Gets the value of the instalmentEndDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getInstalmentEndDate() {
                    return instalmentEndDate;
                }

                /**
                 * Sets the value of the instalmentEndDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setInstalmentEndDate(XMLGregorianCalendar value) {
                    this.instalmentEndDate = value;
                }

                /**
                 * Gets the value of the instalmentDescriptionEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getInstalmentDescriptionEn() {
                    return instalmentDescriptionEn;
                }

                /**
                 * Sets the value of the instalmentDescriptionEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setInstalmentDescriptionEn(String value) {
                    this.instalmentDescriptionEn = value;
                }

                /**
                 * Gets the value of the instalmentDescriptionFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getInstalmentDescriptionFr() {
                    return instalmentDescriptionFr;
                }

                /**
                 * Sets the value of the instalmentDescriptionFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setInstalmentDescriptionFr(String value) {
                    this.instalmentDescriptionFr = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Account" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="AccountAgreement">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Equipment" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                             &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                             &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "account",
            "equipment"
        })
        public static class Contract {

            @XmlElement(name = "Account")
            protected RetrieveLocalAccountResponse.BillAccount.Contract.Account account;
            @XmlElement(name = "Equipment")
            protected RetrieveLocalAccountResponse.BillAccount.Contract.Equipment equipment;

            /**
             * Gets the value of the account property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account }
             *     
             */
            public RetrieveLocalAccountResponse.BillAccount.Contract.Account getAccount() {
                return account;
            }

            /**
             * Sets the value of the account property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account }
             *     
             */
            public void setAccount(RetrieveLocalAccountResponse.BillAccount.Contract.Account value) {
                this.account = value;
            }

            /**
             * Gets the value of the equipment property.
             * 
             * @return
             *     possible object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Equipment }
             *     
             */
            public RetrieveLocalAccountResponse.BillAccount.Contract.Equipment getEquipment() {
                return equipment;
            }

            /**
             * Sets the value of the equipment property.
             * 
             * @param value
             *     allowed object is
             *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Equipment }
             *     
             */
            public void setEquipment(RetrieveLocalAccountResponse.BillAccount.Contract.Equipment value) {
                this.equipment = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="AccountAgreement">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "accountAgreement"
            })
            public static class Account {

                @XmlElement(name = "AccountAgreement", required = true)
                protected RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement accountAgreement;

                /**
                 * Gets the value of the accountAgreement property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement }
                 *     
                 */
                public RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement getAccountAgreement() {
                    return accountAgreement;
                }

                /**
                 * Sets the value of the accountAgreement property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement }
                 *     
                 */
                public void setAccountAgreement(RetrieveLocalAccountResponse.BillAccount.Contract.Account.AccountAgreement value) {
                    this.accountAgreement = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="AgreementSuspensionStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="AgreementExpiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="FreeUpgradesRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "termCode",
                    "termMonth",
                    "agreementActivationDate",
                    "agreementSuspensionStartDate",
                    "agreementExpiryDate",
                    "freeUpgradesRemaining"
                })
                public static class AccountAgreement {

                    @XmlElement(name = "TermCode")
                    protected String termCode;
                    @XmlElement(name = "TermMonth")
                    protected String termMonth;
                    @XmlElement(name = "AgreementActivationDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar agreementActivationDate;
                    @XmlElement(name = "AgreementSuspensionStartDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar agreementSuspensionStartDate;
                    @XmlElement(name = "AgreementExpiryDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar agreementExpiryDate;
                    @XmlElement(name = "FreeUpgradesRemaining")
                    protected String freeUpgradesRemaining;

                    /**
                     * Gets the value of the termCode property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTermCode() {
                        return termCode;
                    }

                    /**
                     * Sets the value of the termCode property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTermCode(String value) {
                        this.termCode = value;
                    }

                    /**
                     * Gets the value of the termMonth property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTermMonth() {
                        return termMonth;
                    }

                    /**
                     * Sets the value of the termMonth property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTermMonth(String value) {
                        this.termMonth = value;
                    }

                    /**
                     * Gets the value of the agreementActivationDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getAgreementActivationDate() {
                        return agreementActivationDate;
                    }

                    /**
                     * Sets the value of the agreementActivationDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setAgreementActivationDate(XMLGregorianCalendar value) {
                        this.agreementActivationDate = value;
                    }

                    /**
                     * Gets the value of the agreementSuspensionStartDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getAgreementSuspensionStartDate() {
                        return agreementSuspensionStartDate;
                    }

                    /**
                     * Sets the value of the agreementSuspensionStartDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setAgreementSuspensionStartDate(XMLGregorianCalendar value) {
                        this.agreementSuspensionStartDate = value;
                    }

                    /**
                     * Gets the value of the agreementExpiryDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getAgreementExpiryDate() {
                        return agreementExpiryDate;
                    }

                    /**
                     * Sets the value of the agreementExpiryDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setAgreementExpiryDate(XMLGregorianCalendar value) {
                        this.agreementExpiryDate = value;
                    }

                    /**
                     * Gets the value of the freeUpgradesRemaining property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getFreeUpgradesRemaining() {
                        return freeUpgradesRemaining;
                    }

                    /**
                     * Sets the value of the freeUpgradesRemaining property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setFreeUpgradesRemaining(String value) {
                        this.freeUpgradesRemaining = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="EquipmentAgreement" maxOccurs="unbounded" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                   &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *                   &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "equipmentAgreement"
            })
            public static class Equipment {

                @XmlElement(name = "EquipmentAgreement")
                protected List<RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement> equipmentAgreement;

                /**
                 * Gets the value of the equipmentAgreement property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the equipmentAgreement property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getEquipmentAgreement().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement }
                 * 
                 * 
                 */
                public List<RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement> getEquipmentAgreement() {
                    if (equipmentAgreement == null) {
                        equipmentAgreement = new ArrayList<RetrieveLocalAccountResponse.BillAccount.Contract.Equipment.EquipmentAgreement>();
                    }
                    return this.equipmentAgreement;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="TermCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="TermMonth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *         &lt;element name="AgreementActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="AgreementDisconnectDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
                 *         &lt;element name="HardwareIdenitifer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
                 *       &lt;/sequence>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "termCode",
                    "termMonth",
                    "agreementActivationDate",
                    "agreementDisconnectDate",
                    "hardwareIdenitifer"
                })
                public static class EquipmentAgreement {

                    @XmlElement(name = "TermCode")
                    protected String termCode;
                    @XmlElement(name = "TermMonth")
                    protected String termMonth;
                    @XmlElement(name = "AgreementActivationDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar agreementActivationDate;
                    @XmlElement(name = "AgreementDisconnectDate")
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar agreementDisconnectDate;
                    @XmlElement(name = "HardwareIdenitifer")
                    protected String hardwareIdenitifer;

                    /**
                     * Gets the value of the termCode property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTermCode() {
                        return termCode;
                    }

                    /**
                     * Sets the value of the termCode property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTermCode(String value) {
                        this.termCode = value;
                    }

                    /**
                     * Gets the value of the termMonth property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTermMonth() {
                        return termMonth;
                    }

                    /**
                     * Sets the value of the termMonth property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTermMonth(String value) {
                        this.termMonth = value;
                    }

                    /**
                     * Gets the value of the agreementActivationDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getAgreementActivationDate() {
                        return agreementActivationDate;
                    }

                    /**
                     * Sets the value of the agreementActivationDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setAgreementActivationDate(XMLGregorianCalendar value) {
                        this.agreementActivationDate = value;
                    }

                    /**
                     * Gets the value of the agreementDisconnectDate property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getAgreementDisconnectDate() {
                        return agreementDisconnectDate;
                    }

                    /**
                     * Sets the value of the agreementDisconnectDate property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setAgreementDisconnectDate(XMLGregorianCalendar value) {
                        this.agreementDisconnectDate = value;
                    }

                    /**
                     * Gets the value of the hardwareIdenitifer property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getHardwareIdenitifer() {
                        return hardwareIdenitifer;
                    }

                    /**
                     * Sets the value of the hardwareIdenitifer property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setHardwareIdenitifer(String value) {
                        this.hardwareIdenitifer = value;
                    }

                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="BillCycleDay" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *         &lt;element name="BillingLanguage" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "billCycleDay",
            "billingLanguage"
        })
        public static class Invoice {

            @XmlElement(name = "BillCycleDay")
            protected Integer billCycleDay;
            @XmlElement(name = "BillingLanguage", required = true)
            protected String billingLanguage;

            /**
             * Gets the value of the billCycleDay property.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getBillCycleDay() {
                return billCycleDay;
            }

            /**
             * Sets the value of the billCycleDay property.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setBillCycleDay(Integer value) {
                this.billCycleDay = value;
            }

            /**
             * Gets the value of the billingLanguage property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBillingLanguage() {
                return billingLanguage;
            }

            /**
             * Sets the value of the billingLanguage property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBillingLanguage(String value) {
                this.billingLanguage = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="PromotionDetails" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="PromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="SubPromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="PromotionDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="PromotionDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="SubPromoDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="SubPromoDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="QualificationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="QualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="DisqualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *                   &lt;element name="TotalPaymentCycles" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *                   &lt;element name="CreditstoBePaidEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="CreditstoBePaidFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="DisqalificationReasonEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="DisqalificationReasonFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="LastCreditAmountPaid" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "promotionDetails"
        })
        public static class Promotions {

            @XmlElement(name = "PromotionDetails")
            protected List<RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails> promotionDetails;

            /**
             * Gets the value of the promotionDetails property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the promotionDetails property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getPromotionDetails().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails }
             * 
             * 
             */
            public List<RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails> getPromotionDetails() {
                if (promotionDetails == null) {
                    promotionDetails = new ArrayList<RetrieveLocalAccountResponse.BillAccount.Promotions.PromotionDetails>();
                }
                return this.promotionDetails;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="PromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="SubPromotionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="PromotionDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="PromotionDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="SubPromoDescriptionEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="SubPromoDescriptionFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="QualificationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="QualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="DisqualificationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
             *         &lt;element name="TotalPaymentCycles" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
             *         &lt;element name="CreditstoBePaidEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="CreditstoBePaidFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="DisqalificationReasonEn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="DisqalificationReasonFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="LastCreditAmountPaid" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "promotionIdentifier",
                "subPromotionIdentifier",
                "promotionDescriptionEn",
                "promotionDescriptionFr",
                "subPromoDescriptionEn",
                "subPromoDescriptionFr",
                "qualificationStatus",
                "qualificationDate",
                "disqualificationDate",
                "totalPaymentCycles",
                "creditstoBePaidEn",
                "creditstoBePaidFr",
                "disqalificationReasonEn",
                "disqalificationReasonFr",
                "lastCreditAmountPaid"
            })
            public static class PromotionDetails {

                @XmlElement(name = "PromotionIdentifier")
                protected String promotionIdentifier;
                @XmlElement(name = "SubPromotionIdentifier")
                protected String subPromotionIdentifier;
                @XmlElement(name = "PromotionDescriptionEn")
                protected String promotionDescriptionEn;
                @XmlElement(name = "PromotionDescriptionFr")
                protected String promotionDescriptionFr;
                @XmlElement(name = "SubPromoDescriptionEn")
                protected String subPromoDescriptionEn;
                @XmlElement(name = "SubPromoDescriptionFr")
                protected String subPromoDescriptionFr;
                @XmlElement(name = "QualificationStatus")
                protected String qualificationStatus;
                @XmlElement(name = "QualificationDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar qualificationDate;
                @XmlElement(name = "DisqualificationDate")
                @XmlSchemaType(name = "date")
                protected XMLGregorianCalendar disqualificationDate;
                @XmlElement(name = "TotalPaymentCycles")
                protected Integer totalPaymentCycles;
                @XmlElement(name = "CreditstoBePaidEn")
                protected String creditstoBePaidEn;
                @XmlElement(name = "CreditstoBePaidFr")
                protected String creditstoBePaidFr;
                @XmlElement(name = "DisqalificationReasonEn")
                protected String disqalificationReasonEn;
                @XmlElement(name = "DisqalificationReasonFr")
                protected String disqalificationReasonFr;
                @XmlElement(name = "LastCreditAmountPaid")
                protected BigDecimal lastCreditAmountPaid;

                /**
                 * Gets the value of the promotionIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPromotionIdentifier() {
                    return promotionIdentifier;
                }

                /**
                 * Sets the value of the promotionIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPromotionIdentifier(String value) {
                    this.promotionIdentifier = value;
                }

                /**
                 * Gets the value of the subPromotionIdentifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSubPromotionIdentifier() {
                    return subPromotionIdentifier;
                }

                /**
                 * Sets the value of the subPromotionIdentifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSubPromotionIdentifier(String value) {
                    this.subPromotionIdentifier = value;
                }

                /**
                 * Gets the value of the promotionDescriptionEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPromotionDescriptionEn() {
                    return promotionDescriptionEn;
                }

                /**
                 * Sets the value of the promotionDescriptionEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPromotionDescriptionEn(String value) {
                    this.promotionDescriptionEn = value;
                }

                /**
                 * Gets the value of the promotionDescriptionFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPromotionDescriptionFr() {
                    return promotionDescriptionFr;
                }

                /**
                 * Sets the value of the promotionDescriptionFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPromotionDescriptionFr(String value) {
                    this.promotionDescriptionFr = value;
                }

                /**
                 * Gets the value of the subPromoDescriptionEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSubPromoDescriptionEn() {
                    return subPromoDescriptionEn;
                }

                /**
                 * Sets the value of the subPromoDescriptionEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSubPromoDescriptionEn(String value) {
                    this.subPromoDescriptionEn = value;
                }

                /**
                 * Gets the value of the subPromoDescriptionFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSubPromoDescriptionFr() {
                    return subPromoDescriptionFr;
                }

                /**
                 * Sets the value of the subPromoDescriptionFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSubPromoDescriptionFr(String value) {
                    this.subPromoDescriptionFr = value;
                }

                /**
                 * Gets the value of the qualificationStatus property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getQualificationStatus() {
                    return qualificationStatus;
                }

                /**
                 * Sets the value of the qualificationStatus property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setQualificationStatus(String value) {
                    this.qualificationStatus = value;
                }

                /**
                 * Gets the value of the qualificationDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getQualificationDate() {
                    return qualificationDate;
                }

                /**
                 * Sets the value of the qualificationDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setQualificationDate(XMLGregorianCalendar value) {
                    this.qualificationDate = value;
                }

                /**
                 * Gets the value of the disqualificationDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getDisqualificationDate() {
                    return disqualificationDate;
                }

                /**
                 * Sets the value of the disqualificationDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setDisqualificationDate(XMLGregorianCalendar value) {
                    this.disqualificationDate = value;
                }

                /**
                 * Gets the value of the totalPaymentCycles property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Integer }
                 *     
                 */
                public Integer getTotalPaymentCycles() {
                    return totalPaymentCycles;
                }

                /**
                 * Sets the value of the totalPaymentCycles property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Integer }
                 *     
                 */
                public void setTotalPaymentCycles(Integer value) {
                    this.totalPaymentCycles = value;
                }

                /**
                 * Gets the value of the creditstoBePaidEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCreditstoBePaidEn() {
                    return creditstoBePaidEn;
                }

                /**
                 * Sets the value of the creditstoBePaidEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCreditstoBePaidEn(String value) {
                    this.creditstoBePaidEn = value;
                }

                /**
                 * Gets the value of the creditstoBePaidFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCreditstoBePaidFr() {
                    return creditstoBePaidFr;
                }

                /**
                 * Sets the value of the creditstoBePaidFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCreditstoBePaidFr(String value) {
                    this.creditstoBePaidFr = value;
                }

                /**
                 * Gets the value of the disqalificationReasonEn property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDisqalificationReasonEn() {
                    return disqalificationReasonEn;
                }

                /**
                 * Sets the value of the disqalificationReasonEn property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDisqalificationReasonEn(String value) {
                    this.disqalificationReasonEn = value;
                }

                /**
                 * Gets the value of the disqalificationReasonFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDisqalificationReasonFr() {
                    return disqalificationReasonFr;
                }

                /**
                 * Sets the value of the disqalificationReasonFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDisqalificationReasonFr(String value) {
                    this.disqalificationReasonFr = value;
                }

                /**
                 * Gets the value of the lastCreditAmountPaid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getLastCreditAmountPaid() {
                    return lastCreditAmountPaid;
                }

                /**
                 * Sets the value of the lastCreditAmountPaid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setLastCreditAmountPaid(BigDecimal value) {
                    this.lastCreditAmountPaid = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SystemCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="SystemMessageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="TransactionId" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="ErrorMessages" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ErrorMessage" maxOccurs="unbounded">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "systemCode",
        "systemMessageType",
        "transactionId",
        "errorMessages"
    })
    public static class ResponseInfo {

        @XmlElement(name = "SystemCode")
        protected int systemCode;
        @XmlElement(name = "SystemMessageType", required = true)
        protected String systemMessageType;
        @XmlElement(name = "TransactionId")
        protected int transactionId;
        @XmlElement(name = "ErrorMessages")
        protected RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages errorMessages;

        /**
         * Gets the value of the systemCode property.
         * 
         */
        public int getSystemCode() {
            return systemCode;
        }

        /**
         * Sets the value of the systemCode property.
         * 
         */
        public void setSystemCode(int value) {
            this.systemCode = value;
        }

        /**
         * Gets the value of the systemMessageType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSystemMessageType() {
            return systemMessageType;
        }

        /**
         * Sets the value of the systemMessageType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSystemMessageType(String value) {
            this.systemMessageType = value;
        }

        /**
         * Gets the value of the transactionId property.
         * 
         */
        public int getTransactionId() {
            return transactionId;
        }

        /**
         * Sets the value of the transactionId property.
         * 
         */
        public void setTransactionId(int value) {
            this.transactionId = value;
        }

        /**
         * Gets the value of the errorMessages property.
         * 
         * @return
         *     possible object is
         *     {@link RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages }
         *     
         */
        public RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages getErrorMessages() {
            return errorMessages;
        }

        /**
         * Sets the value of the errorMessages property.
         * 
         * @param value
         *     allowed object is
         *     {@link RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages }
         *     
         */
        public void setErrorMessages(RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages value) {
            this.errorMessages = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ErrorMessage" maxOccurs="unbounded">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "errorMessage"
        })
        public static class ErrorMessages {

            @XmlElement(name = "ErrorMessage", required = true)
            protected List<RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage> errorMessage;

            /**
             * Gets the value of the errorMessage property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the errorMessage property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getErrorMessage().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage }
             * 
             * 
             */
            public List<RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage> getErrorMessage() {
                if (errorMessage == null) {
                    errorMessage = new ArrayList<RetrieveLocalAccountResponse.ResponseInfo.ErrorMessages.ErrorMessage>();
                }
                return this.errorMessage;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="ErrorMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ErrorMessageText" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="ErrorMessageTextFr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "errorMessageCode",
                "errorMessageText",
                "errorMessageTextFr"
            })
            public static class ErrorMessage {

                @XmlElement(name = "ErrorMessageCode", required = true)
                protected String errorMessageCode;
                @XmlElement(name = "ErrorMessageText", required = true)
                protected String errorMessageText;
                @XmlElement(name = "ErrorMessageTextFr")
                protected String errorMessageTextFr;

                /**
                 * Gets the value of the errorMessageCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageCode() {
                    return errorMessageCode;
                }

                /**
                 * Sets the value of the errorMessageCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageCode(String value) {
                    this.errorMessageCode = value;
                }

                /**
                 * Gets the value of the errorMessageText property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageText() {
                    return errorMessageText;
                }

                /**
                 * Sets the value of the errorMessageText property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageText(String value) {
                    this.errorMessageText = value;
                }

                /**
                 * Gets the value of the errorMessageTextFr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getErrorMessageTextFr() {
                    return errorMessageTextFr;
                }

                /**
                 * Sets the value of the errorMessageTextFr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setErrorMessageTextFr(String value) {
                    this.errorMessageTextFr = value;
                }

            }

        }

    }

}
