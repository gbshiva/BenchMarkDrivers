package transaction.doslb.tv.bell.ca.retrievelocalaccount;

import java.io.*;
import com.terracotta.util.*;
import java.net.*;
import java.util.List;

import javax.xml.namespace.*;

import com.codahale.metrics.Histogram;

public class LocalAccountAccesor implements Runnable {

	private List<String> data;
	private int count = 0;
	private int index = 0;
	private RetrieveLocalAccountTransactionService service;
	private RetrieveLocalAccountTransaction port;
	private Histogram latency;
	boolean random = false;
	private RandomUtil rdmutil = new RandomUtil();
	
	public LocalAccountAccesor(String wsdlurl, List<String> data, int count,
			int index, Histogram latency, boolean random) throws Exception {
		this.data = data;
		this.count = count;
		this.index = index;
		this.latency = latency;
		this.random = random;
		URL wsdlURL = new URL(
				"file:wsdl/retrieveLocalAccountTransaction.wsdl");

		service = new RetrieveLocalAccountTransactionService(wsdlURL,
				RetrieveLocalAccountTransactionService.SERVICE);

		port = service
				.getPort(
						RetrieveLocalAccountTransactionService.RetrieveLocalAccountTransactionSoap11,
						RetrieveLocalAccountTransaction.class);

	}

	@Override
	public void run() {

		for (int i = 0; i < count; i++) {
			
			RetrieveLocalAccountRequest req = new RetrieveLocalAccountRequest();
			if (random){
				
			req.setCSGAccountNumber(data.get(rdmutil.generateRandom(data.size())));
			}else{
				req.setCSGAccountNumber(data.get(i + index));
			}
			req.setApplicationId("MB");
			RetrieveLocalAccountRequest.SectionsRequired sec = new RetrieveLocalAccountRequest.SectionsRequired();
			req.setSectionsRequired(sec);
			
	
			
			
			sec.getSection().add("RA");
			sec.getSection().add("AP");
			sec.getSection().add("PR");
			sec.getSection().add("CO");
			sec.getSection().add("IN");
			sec.getSection().add("IN2");
			
			sec.getSection().add("BBM");

			ExecTime result = new ExecTime();
			result.startRecording();
			RetrieveLocalAccountResponse res = port
					.retrieveLocalAccount(req);
			result.stopRecording();
			latency.update(result.getTimeLapse());
			System.out.println("Server responded with: " + res);

		}
	}
}
