package com.terracotta.util;

import java.util.Date;

public class ExecTime  {
    private boolean complete;
    private Date startDateTime;
    private Date endDateTime;
	
    public boolean isComplete() {
		return complete;
	}
	public void setComplete(boolean complete) {
		this.complete = complete;
	}
	public void startRecording() {
		this.startDateTime = new Date();
	}
	public void stopRecording() {
		this.endDateTime = new Date();
	}
	public long getTimeLapse() {
		if (this.endDateTime != null && this.startDateTime != null) {
			long time = this.endDateTime.getTime() - this.startDateTime.getTime();
			return time;
		}
		return 0;
	}
}