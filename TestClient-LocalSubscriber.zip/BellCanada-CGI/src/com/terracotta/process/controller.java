package com.terracotta.process;

import transaction.doslb.tv.bell.ca.retrievelocalsubscriber.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;

import java.io.InputStreamReader;

import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.CsvReporter;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.MetricRegistry;



public class controller {

	private static String accountNumFile=null;
	private static List<String> accountNumbers = new ArrayList<String>();
	private static int NumAccounts=5000;
	private static int loadThreads=1;
	private static String wsdlurl=null;
	private static final MetricRegistry metrics = new MetricRegistry();
	
public static void main(String args[]){
	
	System.out.println("Usage - <property file> ");
	
	try {
		// Parse input arguments
		if (args.length > 0){
			loadProperties(args[0]);
		}else {
			System.out.println("Missing property file");
			System.exit(1);
		}
		
		final ConsoleReporter reporter = ConsoleReporter.forRegistry(metrics)
                .convertRatesTo(TimeUnit.SECONDS)
                .convertDurationsTo(TimeUnit.MILLISECONDS)
                .build();
		reporter.start(1, TimeUnit.SECONDS);
		
		/**
		final CsvReporter reporter = CsvReporter.forRegistry(metrics)
                .formatFor(Locale.US)
                .convertRatesTo(TimeUnit.SECONDS)
                .convertDurationsTo(TimeUnit.MILLISECONDS)
                .build(new File("/Users/sgokaram/Documents/Client-POCs/BellCanada/data/"));
				reporter.start(1, TimeUnit.SECONDS);
		**/
		readAccountNumber();
		loadSubscribers();	
		
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(2);
		}
	

}

private static void readAccountNumber() throws Exception{
		FileInputStream fis = null;
		BufferedReader reader = null;

          fis = new FileInputStream(accountNumFile);
          reader = new BufferedReader(new InputStreamReader(fis));
        
          System.out.println("Reading AccountNumbers from File");
        
          String line;
          int count = 0;
          while( count < NumAccounts ){
              
        	  line = reader.readLine();
        	  if ( line != null){
        		  System.out.println(line);
        		  accountNumbers.add(line);
              	count++;
        	  }else {
        		  count=NumAccounts;
        	  }
          }           
        
}

private static void loadSubscribers() throws Exception{
	
	Histogram latency = metrics.histogram(MetricRegistry.name(LocalSubscriberAccesor.class, "response-time"));
	
	int count = NumAccounts/loadThreads;
	ExecutorService executor = Executors.newFixedThreadPool(loadThreads);
    for (int i = 0; i < loadThreads; i++) {
      Runnable worker = new LocalSubscriberAccesor(wsdlurl, accountNumbers, count, i*count , latency);
      executor.execute(worker);
    }
	executor.shutdown();
    
	
    
	
}
private static void loadProperties(String propsfile){
		
		try{
			
			Properties prop = new Properties();
	               //load a properties file from class path, inside static method
	    		prop.load(controller.class.getClassLoader().getResourceAsStream(propsfile));
	    		accountNumFile = prop.getProperty("AccountIDFile");
	    		wsdlurl = prop.getProperty("wsdlurl");
	    		NumAccounts = Integer.parseInt(prop.getProperty("NumAccounts"));
	    		loadThreads = Integer.parseInt(prop.getProperty("loadThreads"));
	    		
		}catch(Exception ex){
			System.out.println(ex);
			ex.printStackTrace();
		}
		
		
		
	}
	
	
	
	
	
}
